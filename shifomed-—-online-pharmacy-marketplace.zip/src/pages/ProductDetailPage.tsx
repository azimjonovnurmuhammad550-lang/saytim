import React, { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
  Heart,
  ShoppingBag,
  Minus,
  Plus,
  CheckCircle2,
  AlertCircle,
  FileText,
  Truck,
  Store,
  ShieldCheck,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CATEGORIES } from '../data/categories';
import { PRODUCTS } from '../data/products';
import { formatUZS } from '../i18n/translations';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { ProductCard } from '../components/ProductCard';
import { SafeImage } from '../components/SafeImage';

type DetailTab = 'description' | 'composition' | 'usage' | 'specs';

export const ProductDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { language, t, addToCart, isFavorite, toggleFavorite } = useApp();

  const product = useMemo(() => PRODUCTS.find((p) => p.id === id), [id]);

  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<DetailTab>('description');
  const [rxAcknowledged, setRxAcknowledged] = useState(false);
  const [rxError, setRxError] = useState('');

  useEffect(() => {
    setQuantity(1);
    setActiveTab('description');
    setRxAcknowledged(false);
    setRxError('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [id]);

  if (!product) {
    return (
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10 py-16 text-center">
        <h1 className="font-display text-2xl font-bold text-[#171717] mb-2">
          {t.product.notFoundTitle}
        </h1>
        <p className="text-sm text-[#777777] mb-6">{t.product.notFoundDesc}</p>
        <Link
          to="/catalog"
          className="inline-flex items-center justify-center px-6 py-3 bg-[#171717] hover:bg-[#D71920] text-white text-sm font-semibold rounded-sm transition-colors"
        >
          {t.product.backToCatalog}
        </Link>
      </div>
    );
  }

  const category = CATEGORIES.find((c) => c.id === product.category);
  const favorited = isFavorite(product.id);
  const discountPercent =
    product.previousPriceUZS && product.previousPriceUZS > product.priceUZS
      ? Math.round(((product.previousPriceUZS - product.priceUZS) / product.previousPriceUZS) * 100)
      : null;

  const relatedProducts = PRODUCTS.filter(
    (p) => p.category === product.category && p.id !== product.id
  ).slice(0, 4);

  const handleAddToCart = () => {
    if (!product.inStock) return;
    if (product.isPrescription && !rxAcknowledged) {
      setRxError(t.product.rxAcknowledgeError);
      return;
    }
    setRxError('');
    addToCart(product.id, quantity);
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10 py-8 sm:py-10">
      <Breadcrumbs
        items={[
          { label: t.nav.home, to: '/' },
          { label: t.nav.catalog, to: '/catalog' },
          ...(category
            ? [{ label: category.name[language], to: `/catalog?category=${category.id}` }]
            : []),
          { label: product.name[language] },
        ]}
      />

      {/* Main Contiguous PDP Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
        {/* Left: Product Image Gallery */}
        <div className="lg:col-span-6 lg:sticky lg:top-24">
          <div className="relative aspect-[4/3] bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm overflow-hidden">
            <SafeImage
              src={product.image}
              alt={product.name[language]}
              fallbackLabel={product.name[language]}
              className="w-full h-full object-cover"
            />
            {discountPercent && (
              <span className="absolute top-4 left-4 bg-[#D71920] text-white text-xs font-bold px-2.5 py-1 rounded-sm tabular-nums">
                -{discountPercent}%
              </span>
            )}
          </div>
        </div>

        {/* Right: Contiguous Purchase Module */}
        <div className="lg:col-span-6">
          <div className="flex items-center flex-wrap gap-2 text-xs text-[#777777] mb-2">
            <span className="font-semibold text-[#171717]">{product.brand}</span>
            <span aria-hidden="true">·</span>
            <span>{category?.name[language]}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono-num">
              {t.product.sku}: {product.sku}
            </span>
          </div>

          <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-[#171717] tracking-tight leading-tight mb-4">
            {product.name[language]}
          </h1>

          {/* Price Block */}
          <div className="flex items-baseline flex-wrap gap-3 pb-5 mb-5 border-b border-[#E8E8E8]">
            <span className="font-display text-2xl sm:text-3xl font-extrabold text-[#171717] tabular-nums">
              {formatUZS(product.priceUZS, language)}
            </span>
            {product.previousPriceUZS && (
              <span className="text-base text-[#777777] line-through tabular-nums">
                {formatUZS(product.previousPriceUZS, language)}
              </span>
            )}
            {discountPercent && (
              <span className="text-xs font-semibold text-[#D71920]">
                -{discountPercent}%
              </span>
            )}
          </div>

          {/* Availability & Dispensing Row */}
          <div className="flex flex-wrap items-center gap-4 text-sm mb-5">
            {product.inStock ? (
              <span className="inline-flex items-center gap-1.5 text-[#171717] font-medium">
                <CheckCircle2 className="w-4 h-4 text-[#171717]" aria-hidden="true" />
                {t.product.inStock} ({product.stockCount})
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 text-[#777777] font-medium">
                <AlertCircle className="w-4 h-4 text-[#777777]" aria-hidden="true" />
                {t.product.outOfStock}
              </span>
            )}

            <span className="text-[#E8E8E8]" aria-hidden="true">|</span>

            {product.isPrescription ? (
              <span className="inline-flex items-center gap-1.5 text-[#D71920] font-semibold">
                <FileText className="w-4 h-4" aria-hidden="true" />
                {t.product.prescriptionRequired}
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 text-[#242424]">
                <ShieldCheck className="w-4 h-4 text-[#777777]" aria-hidden="true" />
                {t.product.otcLabel}
              </span>
            )}
          </div>

          {/* Prescription Warning Box */}
          {product.isPrescription && (
            <div className="p-4 mb-6 bg-[#F7F7F7] border border-[#D71920]/40 rounded-sm">
              <div className="flex items-start gap-2.5 mb-2">
                <FileText className="w-4 h-4 text-[#D71920] mt-0.5 shrink-0" aria-hidden="true" />
                <div>
                  <h2 className="text-sm font-bold text-[#171717]">{t.product.rxNoticeTitle}</h2>
                  <p className="text-xs sm:text-sm text-[#242424] leading-relaxed mt-1">
                    {t.product.rxNoticeBody}
                  </p>
                </div>
              </div>
              <label className="flex items-start gap-2.5 mt-3 pt-3 border-t border-[#E8E8E8] cursor-pointer text-xs sm:text-sm text-[#171717] font-medium">
                <input
                  type="checkbox"
                  checked={rxAcknowledged}
                  onChange={(e) => {
                    setRxAcknowledged(e.target.checked);
                    if (e.target.checked) setRxError('');
                  }}
                  className="mt-0.5 w-4 h-4 accent-[#D71920] shrink-0"
                />
                <span>{t.product.rxAcknowledge}</span>
              </label>
              {rxError && (
                <p className="text-xs text-[#D71920] font-semibold mt-2">{rxError}</p>
              )}
            </div>
          )}

          {/* Quantity & Actions */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 mb-6">
            <div className="inline-flex items-center justify-between border border-[#E8E8E8] rounded-sm h-12 px-2 bg-white sm:w-36 shrink-0">
              <button
                type="button"
                aria-label="Decrease quantity"
                disabled={!product.inStock || quantity <= 1}
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                className="w-8 h-8 flex items-center justify-center text-[#171717] disabled:text-[#777777] hover:bg-[#F7F7F7] rounded-sm cursor-pointer"
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="text-sm font-bold text-[#171717] tabular-nums">{quantity}</span>
              <button
                type="button"
                aria-label="Increase quantity"
                disabled={!product.inStock || quantity >= product.stockCount}
                onClick={() => setQuantity((q) => Math.min(product.stockCount, q + 1))}
                className="w-8 h-8 flex items-center justify-center text-[#171717] disabled:text-[#777777] hover:bg-[#F7F7F7] rounded-sm cursor-pointer"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            <button
              type="button"
              disabled={!product.inStock}
              onClick={handleAddToCart}
              className={`flex-1 h-12 px-6 inline-flex items-center justify-center gap-2 text-sm font-semibold rounded-sm transition-colors whitespace-nowrap ${
                product.inStock
                  ? 'bg-[#D71920] hover:bg-[#B5121B] text-white cursor-pointer'
                  : 'bg-[#F7F7F7] text-[#777777] border border-[#E8E8E8] cursor-not-allowed'
              }`}
            >
              <ShoppingBag className="w-4 h-4" aria-hidden="true" />
              <span>{t.product.addToCart}</span>
            </button>

            <button
              type="button"
              onClick={() => toggleFavorite(product.id)}
              aria-pressed={favorited}
              aria-label={favorited ? t.product.removeFromFavorites : t.product.addToFavorites}
              className={`h-12 px-4 inline-flex items-center justify-center gap-2 border rounded-sm text-sm font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                favorited
                  ? 'bg-[#171717] border-[#171717] text-white'
                  : 'bg-white border-[#E8E8E8] hover:border-[#171717] text-[#171717]'
              }`}
            >
              <Heart className={`w-4 h-4 ${favorited ? 'fill-current' : ''}`} />
              <span className="sm:hidden lg:inline">
                {favorited ? t.product.removeFromFavorites : t.product.addToFavorites}
              </span>
            </button>
          </div>

          {/* Key Metadata Table */}
          <dl className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm text-xs mb-6">
            <div>
              <dt className="text-[#777777]">{t.product.dosageForm}</dt>
              <dd className="font-semibold text-[#171717] mt-0.5">{product.dosageForm[language]}</dd>
            </div>
            <div>
              <dt className="text-[#777777]">{t.product.packSize}</dt>
              <dd className="font-semibold text-[#171717] mt-0.5">{product.packSize[language]}</dd>
            </div>
            <div className="sm:col-span-2">
              <dt className="text-[#777777]">{t.product.manufacturer}</dt>
              <dd className="font-semibold text-[#171717] mt-0.5">{product.manufacturer[language]}</dd>
            </div>
          </dl>

          {/* Delivery Summary */}
          <div className="p-4 border border-[#E8E8E8] rounded-sm space-y-2 text-xs text-[#242424]">
            <div className="font-semibold text-[#171717] mb-1">{t.product.deliverySummaryTitle}</div>
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-[#D71920] shrink-0" aria-hidden="true" />
              <span>{t.product.deliverySummaryExpress}</span>
            </div>
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-[#777777] shrink-0" aria-hidden="true" />
              <span>{t.product.deliverySummaryStandard}</span>
            </div>
            <div className="flex items-center gap-2">
              <Store className="w-4 h-4 text-[#777777] shrink-0" aria-hidden="true" />
              <span>{t.product.deliverySummaryPickup}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Detailed Information Tabs */}
      <section className="mt-14 pt-10 border-t border-[#E8E8E8]">
        <div
          role="tablist"
          className="flex items-center gap-1 border-b border-[#E8E8E8] overflow-x-auto mb-6"
        >
          {(
            [
              { id: 'description', label: t.product.tabs.description },
              { id: 'composition', label: t.product.tabs.composition },
              { id: 'usage', label: t.product.tabs.usage },
              { id: 'specs', label: t.product.tabs.specs },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              role="tab"
              aria-selected={activeTab === tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-5 py-3 text-sm font-semibold border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === tab.id
                  ? 'border-[#D71920] text-[#171717]'
                  : 'border-transparent text-[#777777] hover:text-[#171717]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="max-w-3xl text-sm sm:text-base text-[#242424] leading-relaxed">
          {activeTab === 'description' && <p>{product.description[language]}</p>}
          {activeTab === 'composition' && <p>{product.composition[language]}</p>}
          {activeTab === 'usage' && <p>{product.usage[language]}</p>}
          {activeTab === 'specs' && (
            <dl className="divide-y divide-[#E8E8E8] border border-[#E8E8E8] rounded-sm">
              {product.specifications.map((spec, idx) => (
                <div key={idx} className="grid grid-cols-1 sm:grid-cols-3 gap-2 p-3.5 text-sm">
                  <dt className="text-[#777777]">{spec.label[language]}</dt>
                  <dd className="sm:col-span-2 font-medium text-[#171717]">{spec.value[language]}</dd>
                </div>
              ))}
            </dl>
          )}
        </div>
      </section>

      {/* Related Products */}
      {relatedProducts.length > 0 && (
        <section className="mt-16 pt-10 border-t border-[#E8E8E8]">
          <h2 className="font-display text-2xl font-bold text-[#171717] tracking-tight mb-6">
            {t.product.relatedTitle}
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {relatedProducts.map((item) => (
              <ProductCard key={item.id} product={item} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
