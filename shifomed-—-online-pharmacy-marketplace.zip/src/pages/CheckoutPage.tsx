import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, FileText, Printer, ArrowRight, ShieldCheck } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { DELIVERY_FEES, formatUZS } from '../i18n/translations';
import { DeliveryMethodId, OrderRecord } from '../types';
import { Breadcrumbs } from '../components/Breadcrumbs';

export const CheckoutPage: React.FC = () => {
  const {
    language,
    t,
    cartProducts,
    subtotalUZS,
    discountSavingsUZS,
    hasPrescriptionItemsInCart,
    deliveryMethod,
    setDeliveryMethod,
    deliveryCostUZS,
    totalUZS,
    clearCart,
    saveOrder,
  } = useApp();

  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [rxConfirmed, setRxConfirmed] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [confirmedOrder, setConfirmedOrder] = useState<OrderRecord | null>(null);

  const deliveryOptions: { id: DeliveryMethodId; priceText: string }[] = [
    {
      id: 'standard',
      priceText:
        subtotalUZS >= DELIVERY_FEES.freeStandardThreshold
          ? t.cart.free
          : formatUZS(DELIVERY_FEES.standard, language),
    },
    {
      id: 'express',
      priceText: formatUZS(DELIVERY_FEES.express, language),
    },
    {
      id: 'pickup',
      priceText: t.cart.free,
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const nextErrors: Record<string, string> = {};

    if (fullName.trim().length < 3) {
      nextErrors.fullName = t.checkout.validation.nameRequired;
    }

    const digitsOnly = phone.replace(/\D/g, '');
    if (digitsOnly.length < 9) {
      nextErrors.phone = t.checkout.validation.phoneInvalid;
    }

    if (deliveryMethod !== 'pickup' && address.trim().length < 5) {
      nextErrors.address = t.checkout.validation.addressRequired;
    }

    if (hasPrescriptionItemsInCart && !rxConfirmed) {
      nextErrors.rx = t.checkout.validation.rxRequired;
    }

    if (Object.keys(nextErrors).length > 0) {
      setErrors(nextErrors);
      return;
    }

    const randomCode = Math.floor(1000 + Math.random() * 9000);
    const newOrder: OrderRecord = {
      orderNumber: `SHF-2026-${randomCode}`,
      createdAt: new Date().toISOString(),
      customerName: fullName.trim(),
      phone: phone.trim(),
      address:
        deliveryMethod === 'pickup' ? t.checkout.pickupAddressValue : address.trim(),
      notes: notes.trim() || undefined,
      deliveryMethod,
      deliveryCostUZS,
      subtotalUZS,
      discountUZS: discountSavingsUZS,
      totalUZS,
      hasPrescriptionItems: hasPrescriptionItemsInCart,
      items: cartProducts.map(({ product, quantity }) => ({
        productId: product.id,
        name: product.name,
        brand: product.brand,
        priceUZS: product.priceUZS,
        quantity,
        isPrescription: product.isPrescription,
      })),
    };

    saveOrder(newOrder);
    clearCart();
    setConfirmedOrder(newOrder);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (confirmedOrder) {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12 sm:py-16">
        <div className="bg-white border border-[#E8E8E8] rounded-sm p-6 sm:p-10">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#D71920] mb-3">
            <CheckCircle2 className="w-4 h-4" />
            <span>{t.checkout.success.badge}</span>
          </div>

          <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-[#171717] tracking-tight mb-3">
            {t.checkout.success.title}
          </h1>
          <p className="text-sm text-[#242424] leading-relaxed mb-6">
            {t.checkout.success.subtitle}
          </p>

          <div className="p-4 bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm flex flex-wrap items-center justify-between gap-4 mb-6">
            <div>
              <div className="text-xs text-[#777777]">{t.checkout.success.orderNumber}</div>
              <div className="font-mono-num text-lg font-bold text-[#171717]">
                {confirmedOrder.orderNumber}
              </div>
            </div>
            <div className="text-right">
              <div className="text-xs text-[#777777]">{t.cart.total}</div>
              <div className="font-display text-lg font-extrabold text-[#D71920] tabular-nums">
                {formatUZS(confirmedOrder.totalUZS, language)}
              </div>
            </div>
          </div>

          <dl className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm pb-6 mb-6 border-b border-[#E8E8E8]">
            <div>
              <dt className="text-xs text-[#777777]">{t.checkout.success.recipient}</dt>
              <dd className="font-semibold text-[#171717] mt-0.5">{confirmedOrder.customerName}</dd>
              <dd className="text-xs text-[#242424] font-mono-num mt-0.5">{confirmedOrder.phone}</dd>
            </div>
            <div>
              <dt className="text-xs text-[#777777]">{t.checkout.success.deliveryType}</dt>
              <dd className="font-semibold text-[#171717] mt-0.5">
                {t.deliveryMethods[confirmedOrder.deliveryMethod].title}
              </dd>
              <dd className="text-xs text-[#242424] mt-0.5">{confirmedOrder.address}</dd>
            </div>
          </dl>

          <div className="mb-8">
            <h2 className="text-sm font-bold text-[#171717] mb-3">
              {t.checkout.success.itemsTitle}
            </h2>
            <ul className="divide-y divide-[#E8E8E8] border border-[#E8E8E8] rounded-sm text-sm">
              {confirmedOrder.items.map((item) => (
                <li
                  key={item.productId}
                  className="p-3.5 flex items-center justify-between gap-4"
                >
                  <div className="min-w-0">
                    <div className="font-medium text-[#171717] truncate">
                      {item.name[language]}
                    </div>
                    <div className="text-xs text-[#777777] tabular-nums">
                      {item.brand} · {item.quantity} × {formatUZS(item.priceUZS, language)}
                    </div>
                  </div>
                  <div className="font-bold text-[#171717] tabular-nums whitespace-nowrap">
                    {formatUZS(item.priceUZS * item.quantity, language)}
                  </div>
                </li>
              ))}
            </ul>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => window.print()}
              className="h-11 px-5 border border-[#E8E8E8] hover:border-[#171717] text-[#171717] text-sm font-semibold rounded-sm inline-flex items-center gap-2 transition-colors cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>{t.checkout.success.printReceipt}</span>
            </button>
            <Link
              to="/catalog"
              className="h-11 px-6 bg-[#D71920] hover:bg-[#B5121B] text-white text-sm font-semibold rounded-sm inline-flex items-center gap-2 transition-colors"
            >
              <span>{t.checkout.success.continueCatalog}</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              to="/"
              className="h-11 px-5 text-sm font-semibold text-[#777777] hover:text-[#171717] inline-flex items-center"
            >
              {t.checkout.success.backHome}
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (cartProducts.length === 0) {
    return (
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10 py-14">
        <div className="bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm p-12 text-center max-w-xl mx-auto">
          <h1 className="font-display text-xl font-bold text-[#171717] mb-2">
            {t.cart.emptyTitle}
          </h1>
          <p className="text-sm text-[#777777] mb-6">{t.cart.emptyDesc}</p>
          <Link
            to="/catalog"
            className="inline-flex items-center gap-2 px-6 py-3 bg-[#D71920] hover:bg-[#B5121B] text-white text-sm font-semibold rounded-sm transition-colors"
          >
            <span>{t.cart.continueShopping}</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10 py-8 sm:py-10">
      <Breadcrumbs
        items={[
          { label: t.nav.home, to: '/' },
          { label: t.cart.title, to: '/cart' },
          { label: t.checkout.title },
        ]}
      />

      <div className="pb-6 mb-8 border-b border-[#E8E8E8]">
        <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-[#171717] tracking-tight">
          {t.checkout.title}
        </h1>
        <p className="text-sm text-[#777777] mt-1.5">{t.checkout.subtitle}</p>
      </div>

      <form onSubmit={handleSubmit} noValidate className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: Form */}
        <div className="lg:col-span-7 space-y-6">
          {/* Customer Details */}
          <div className="bg-white border border-[#E8E8E8] rounded-sm p-6 space-y-5">
            <h2 className="font-display text-lg font-bold text-[#171717]">
              {t.checkout.customerInfo}
            </h2>

            <div>
              <label htmlFor="fullName" className="block text-xs font-semibold text-[#171717] mb-1.5">
                {t.checkout.fullName} *
              </label>
              <input
                id="fullName"
                type="text"
                value={fullName}
                onChange={(e) => {
                  setFullName(e.target.value);
                  if (errors.fullName) setErrors((prev) => ({ ...prev, fullName: '' }));
                }}
                placeholder={t.checkout.fullNamePlaceholder}
                className="w-full h-11 px-3.5 text-sm bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm text-[#171717] focus:bg-white focus:border-[#171717] focus:outline-none"
              />
              {errors.fullName && (
                <p className="text-xs text-[#D71920] font-medium mt-1.5">{errors.fullName}</p>
              )}
            </div>

            <div>
              <label htmlFor="phone" className="block text-xs font-semibold text-[#171717] mb-1.5">
                {t.checkout.phone} *
              </label>
              <input
                id="phone"
                type="tel"
                value={phone}
                onChange={(e) => {
                  setPhone(e.target.value);
                  if (errors.phone) setErrors((prev) => ({ ...prev, phone: '' }));
                }}
                placeholder={t.checkout.phonePlaceholder}
                className="w-full h-11 px-3.5 text-sm bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm text-[#171717] font-mono-num focus:bg-white focus:border-[#171717] focus:outline-none"
              />
              {errors.phone && (
                <p className="text-xs text-[#D71920] font-medium mt-1.5">{errors.phone}</p>
              )}
            </div>

            {deliveryMethod !== 'pickup' && (
              <div>
                <label htmlFor="address" className="block text-xs font-semibold text-[#171717] mb-1.5">
                  {t.checkout.address} *
                </label>
                <input
                  id="address"
                  type="text"
                  value={address}
                  onChange={(e) => {
                    setAddress(e.target.value);
                    if (errors.address) setErrors((prev) => ({ ...prev, address: '' }));
                  }}
                  placeholder={t.checkout.addressPlaceholder}
                  className="w-full h-11 px-3.5 text-sm bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm text-[#171717] focus:bg-white focus:border-[#171717] focus:outline-none"
                />
                {errors.address && (
                  <p className="text-xs text-[#D71920] font-medium mt-1.5">{errors.address}</p>
                )}
              </div>
            )}

            <div>
              <label htmlFor="notes" className="block text-xs font-semibold text-[#171717] mb-1.5">
                {t.checkout.notes}
              </label>
              <textarea
                id="notes"
                rows={3}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder={t.checkout.notesPlaceholder}
                className="w-full p-3.5 text-sm bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm text-[#171717] focus:bg-white focus:border-[#171717] focus:outline-none"
              />
            </div>
          </div>

          {/* Delivery Method */}
          <div className="bg-white border border-[#E8E8E8] rounded-sm p-6">
            <h2 className="font-display text-lg font-bold text-[#171717] mb-4">
              {t.checkout.deliverySection}
            </h2>
            <div className="space-y-3">
              {deliveryOptions.map((opt) => (
                <label
                  key={opt.id}
                  className={`flex items-start justify-between gap-3 p-4 border rounded-sm cursor-pointer transition-colors ${
                    deliveryMethod === opt.id
                      ? 'border-[#171717] bg-[#F7F7F7]'
                      : 'border-[#E8E8E8] hover:border-[#777777]'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <input
                      type="radio"
                      name="checkout-delivery"
                      checked={deliveryMethod === opt.id}
                      onChange={() => setDeliveryMethod(opt.id)}
                      className="mt-1 accent-[#D71920]"
                    />
                    <div>
                      <div className="text-sm font-semibold text-[#171717]">
                        {t.deliveryMethods[opt.id].title}
                      </div>
                      <div className="text-xs text-[#777777] mt-0.5">
                        {t.deliveryMethods[opt.id].desc}
                      </div>
                    </div>
                  </div>
                  <span className="text-sm font-bold text-[#171717] tabular-nums whitespace-nowrap">
                    {opt.priceText}
                  </span>
                </label>
              ))}
            </div>
          </div>

          {/* Payment Terms Note */}
          <div className="bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm p-5 flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-[#171717] mt-0.5 shrink-0" />
            <div>
              <h3 className="text-sm font-bold text-[#171717]">{t.checkout.paymentInfoTitle}</h3>
              <p className="text-xs sm:text-sm text-[#242424] leading-relaxed mt-1">
                {t.checkout.paymentInfoDesc}
              </p>
            </div>
          </div>

          {/* Prescription Confirmation */}
          {hasPrescriptionItemsInCart && (
            <div className="bg-white border border-[#D71920]/40 rounded-sm p-5">
              <label className="flex items-start gap-3 cursor-pointer text-sm text-[#171717] font-medium">
                <input
                  type="checkbox"
                  checked={rxConfirmed}
                  onChange={(e) => {
                    setRxConfirmed(e.target.checked);
                    if (e.target.checked) setErrors((prev) => ({ ...prev, rx: '' }));
                  }}
                  className="mt-1 w-4 h-4 accent-[#D71920] shrink-0"
                />
                <span>{t.checkout.rxConfirmLabel}</span>
              </label>
              {errors.rx && (
                <p className="text-xs text-[#D71920] font-semibold mt-2">{errors.rx}</p>
              )}
            </div>
          )}
        </div>

        {/* Right: Order Summary */}
        <aside className="lg:col-span-5 bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm p-6 sticky top-24">
          <h2 className="font-display text-lg font-bold text-[#171717] pb-4 mb-4 border-b border-[#E8E8E8]">
            {t.cart.summaryTitle}
          </h2>

          <ul className="divide-y divide-[#E8E8E8] mb-5 max-h-80 overflow-y-auto pr-1">
            {cartProducts.map(({ product, quantity }) => (
              <li key={product.id} className="py-3 flex items-start justify-between gap-3 text-sm">
                <div className="min-w-0">
                  <div className="font-medium text-[#171717] leading-snug">
                    {product.name[language]}
                  </div>
                  <div className="text-xs text-[#777777] mt-0.5 tabular-nums">
                    {quantity} × {formatUZS(product.priceUZS, language)}
                    {product.isPrescription && (
                      <span className="ml-2 text-[#D71920] font-semibold inline-flex items-center gap-1">
                        <FileText className="w-3 h-3" /> Rx
                      </span>
                    )}
                  </div>
                </div>
                <div className="font-bold text-[#171717] tabular-nums whitespace-nowrap">
                  {formatUZS(product.priceUZS * quantity, language)}
                </div>
              </li>
            ))}
          </ul>

          <dl className="space-y-2.5 text-sm pt-4 border-t border-[#E8E8E8]">
            <div className="flex items-center justify-between">
              <dt className="text-[#777777]">{t.cart.subtotal}</dt>
              <dd className="font-semibold text-[#171717] tabular-nums">
                {formatUZS(subtotalUZS, language)}
              </dd>
            </div>
            {discountSavingsUZS > 0 && (
              <div className="flex items-center justify-between">
                <dt className="text-[#777777]">{t.cart.discount}</dt>
                <dd className="font-semibold text-[#D71920] tabular-nums">
                  -{formatUZS(discountSavingsUZS, language)}
                </dd>
              </div>
            )}
            <div className="flex items-center justify-between">
              <dt className="text-[#777777]">{t.cart.deliveryCost}</dt>
              <dd className="font-semibold text-[#171717] tabular-nums">
                {deliveryCostUZS === 0 ? t.cart.free : formatUZS(deliveryCostUZS, language)}
              </dd>
            </div>
            <div className="flex items-center justify-between pt-3 border-t border-[#E8E8E8] text-base font-extrabold text-[#171717]">
              <dt>{t.cart.total}</dt>
              <dd className="tabular-nums">{formatUZS(totalUZS, language)}</dd>
            </div>
          </dl>

          <button
            type="submit"
            className="mt-6 w-full h-12 bg-[#D71920] hover:bg-[#B5121B] text-white text-sm font-semibold rounded-sm transition-colors cursor-pointer"
          >
            {t.checkout.confirmOrder}
          </button>
        </aside>
      </form>
    </div>
  );
};
