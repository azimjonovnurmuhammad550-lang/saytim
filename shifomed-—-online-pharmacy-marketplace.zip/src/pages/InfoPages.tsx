import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Clock, ChevronDown, ArrowRight, CheckCircle2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { IMAGES } from '../data/categories';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { SafeImage } from '../components/SafeImage';

export const AboutPage: React.FC = () => {
  const { t } = useApp();

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10 py-8 sm:py-10">
      <Breadcrumbs items={[{ label: t.nav.home, to: '/' }, { label: t.pages.about.title }]} />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch pb-12 border-b border-[#E8E8E8]">
        <div className="lg:col-span-6 flex flex-col justify-center">
          <h1 className="font-display text-3xl sm:text-4xl font-extrabold text-[#171717] tracking-tight mb-4">
            {t.pages.about.title}
          </h1>
          <p className="text-base sm:text-lg text-[#242424] leading-relaxed mb-8">
            {t.pages.about.lead}
          </p>
          <div className="grid grid-cols-3 gap-4 pt-6 border-t border-[#E8E8E8]">
            {t.pages.about.stats.map((stat, idx) => (
              <div key={idx}>
                <div className="font-display text-2xl font-extrabold text-[#D71920] tabular-nums">
                  {stat.value}
                </div>
                <div className="text-xs text-[#777777] mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-6 aspect-[16/10] lg:aspect-auto min-h-[260px] bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm overflow-hidden">
          <SafeImage src={IMAGES.hero} alt={t.pages.about.title} className="w-full h-full object-cover" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-12">
        {t.pages.about.sections.map((section, idx) => (
          <div key={idx} className="p-6 bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm">
            <h2 className="font-display text-lg font-bold text-[#171717] mb-3">
              {section.heading}
            </h2>
            <p className="text-sm text-[#242424] leading-relaxed">{section.body}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export const ContactPage: React.FC = () => {
  const { t, showToast } = useApp();
  const [name, setName] = useState('');
  const [contact, setContact] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !contact.trim() || !message.trim()) {
      setError(t.pages.contact.validationError);
      return;
    }
    setError('');
    setSent(true);
    setName('');
    setContact('');
    setMessage('');
    showToast(t.toasts.contactSent, 'success');
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10 py-8 sm:py-10">
      <Breadcrumbs items={[{ label: t.nav.home, to: '/' }, { label: t.pages.contact.title }]} />

      <div className="max-w-2xl pb-8 mb-8 border-b border-[#E8E8E8]">
        <h1 className="font-display text-3xl font-extrabold text-[#171717] tracking-tight mb-3">
          {t.pages.contact.title}
        </h1>
        <p className="text-base text-[#242424]">{t.pages.contact.lead}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        <div className="lg:col-span-5 space-y-4">
          <div className="p-5 bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm flex items-start gap-3">
            <Phone className="w-5 h-5 text-[#D71920] mt-0.5 shrink-0" />
            <div>
              <div className="text-xs text-[#777777]">{t.pages.contact.phoneLabel}</div>
              <div className="text-sm font-bold text-[#171717] font-mono-num mt-0.5">
                +998 71 200 48 48
              </div>
            </div>
          </div>
          <div className="p-5 bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm flex items-start gap-3">
            <Mail className="w-5 h-5 text-[#D71920] mt-0.5 shrink-0" />
            <div>
              <div className="text-xs text-[#777777]">{t.pages.contact.emailLabel}</div>
              <div className="text-sm font-bold text-[#171717] mt-0.5">care@shifomed.uz</div>
            </div>
          </div>
          <div className="p-5 bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm flex items-start gap-3">
            <MapPin className="w-5 h-5 text-[#D71920] mt-0.5 shrink-0" />
            <div>
              <div className="text-xs text-[#777777]">{t.pages.contact.addressLabel}</div>
              <div className="text-sm font-medium text-[#171717] mt-0.5">{t.footer.address}</div>
            </div>
          </div>
          <div className="p-5 bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm flex items-start gap-3">
            <Clock className="w-5 h-5 text-[#D71920] mt-0.5 shrink-0" />
            <div>
              <div className="text-xs text-[#777777]">{t.pages.contact.hoursLabel}</div>
              <div className="text-sm font-medium text-[#171717] mt-0.5">{t.footer.hours}</div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-7 bg-white border border-[#E8E8E8] rounded-sm p-6 sm:p-8">
          <h2 className="font-display text-xl font-bold text-[#171717] mb-5">
            {t.pages.contact.formTitle}
          </h2>
          {sent ? (
            <div className="p-5 bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm flex items-center gap-3 text-sm font-medium text-[#171717]">
              <CheckCircle2 className="w-5 h-5 text-[#D71920] shrink-0" />
              <span>{t.toasts.contactSent}</span>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-[#171717] mb-1.5">
                  {t.pages.contact.nameLabel}
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full h-11 px-3.5 text-sm bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm focus:bg-white focus:border-[#171717] focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#171717] mb-1.5">
                  {t.pages.contact.emailInputLabel}
                </label>
                <input
                  type="text"
                  value={contact}
                  onChange={(e) => setContact(e.target.value)}
                  className="w-full h-11 px-3.5 text-sm bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm focus:bg-white focus:border-[#171717] focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#171717] mb-1.5">
                  {t.pages.contact.messageLabel}
                </label>
                <textarea
                  rows={4}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full p-3.5 text-sm bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm focus:bg-white focus:border-[#171717] focus:outline-none"
                />
              </div>
              {error && <p className="text-xs text-[#D71920] font-semibold">{error}</p>}
              <button
                type="submit"
                className="h-11 px-6 bg-[#D71920] hover:bg-[#B5121B] text-white text-sm font-semibold rounded-sm transition-colors cursor-pointer"
              >
                {t.pages.contact.sendBtn}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export const FaqPage: React.FC = () => {
  const { t } = useApp();
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
      <Breadcrumbs items={[{ label: t.nav.home, to: '/' }, { label: t.pages.faq.title }]} />

      <div className="pb-8 mb-8 border-b border-[#E8E8E8]">
        <h1 className="font-display text-3xl font-extrabold text-[#171717] tracking-tight mb-3">
          {t.pages.faq.title}
        </h1>
        <p className="text-base text-[#242424]">{t.pages.faq.lead}</p>
      </div>

      <div className="border border-[#E8E8E8] rounded-sm divide-y divide-[#E8E8E8] bg-white">
        {t.pages.faq.items.map((item, idx) => {
          const isOpen = openIndex === idx;
          return (
            <div key={idx}>
              <button
                type="button"
                aria-expanded={isOpen}
                onClick={() => setOpenIndex(isOpen ? null : idx)}
                className="w-full text-left p-5 flex items-center justify-between gap-4 hover:bg-[#F7F7F7] transition-colors cursor-pointer"
              >
                <span className="text-base font-semibold text-[#171717]">{item.q}</span>
                <ChevronDown
                  className={`w-5 h-5 text-[#777777] shrink-0 transition-transform ${
                    isOpen ? 'rotate-180 text-[#D71920]' : ''
                  }`}
                />
              </button>
              {isOpen && (
                <div className="px-5 pb-5 text-sm text-[#242424] leading-relaxed">
                  {item.a}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export const DeliveryPage: React.FC = () => {
  const { t } = useApp();

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10 py-8 sm:py-10">
      <Breadcrumbs items={[{ label: t.nav.home, to: '/' }, { label: t.pages.delivery.title }]} />

      <div className="max-w-2xl pb-8 mb-8 border-b border-[#E8E8E8]">
        <h1 className="font-display text-3xl font-extrabold text-[#171717] tracking-tight mb-3">
          {t.pages.delivery.title}
        </h1>
        <p className="text-base text-[#242424]">{t.pages.delivery.lead}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        {t.pages.delivery.cards.map((card, idx) => (
          <div key={idx} className="p-6 bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm">
            <h2 className="font-display text-lg font-bold text-[#171717] mb-3">{card.title}</h2>
            <p className="text-sm text-[#242424] leading-relaxed">{card.body}</p>
          </div>
        ))}
      </div>

      <Link
        to="/catalog"
        className="inline-flex items-center gap-2 px-6 py-3 bg-[#D71920] hover:bg-[#B5121B] text-white text-sm font-semibold rounded-sm transition-colors"
      >
        <span>{t.hero.primaryCta}</span>
        <ArrowRight className="w-4 h-4" />
      </Link>
    </div>
  );
};

export const PrivacyPage: React.FC = () => {
  const { t } = useApp();

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
      <Breadcrumbs items={[{ label: t.nav.home, to: '/' }, { label: t.pages.privacy.title }]} />
      <h1 className="font-display text-3xl font-extrabold text-[#171717] tracking-tight mb-3">
        {t.pages.privacy.title}
      </h1>
      <p className="text-base text-[#777777] pb-6 mb-6 border-b border-[#E8E8E8]">
        {t.pages.privacy.lead}
      </p>
      <div className="space-y-4 text-sm sm:text-base text-[#242424] leading-relaxed">
        {t.pages.privacy.paragraphs.map((p, idx) => (
          <p key={idx}>{p}</p>
        ))}
      </div>
    </div>
  );
};

export const TermsPage: React.FC = () => {
  const { t } = useApp();

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
      <Breadcrumbs items={[{ label: t.nav.home, to: '/' }, { label: t.pages.terms.title }]} />
      <h1 className="font-display text-3xl font-extrabold text-[#171717] tracking-tight mb-3">
        {t.pages.terms.title}
      </h1>
      <p className="text-base text-[#777777] pb-6 mb-6 border-b border-[#E8E8E8]">
        {t.pages.terms.lead}
      </p>
      <div className="space-y-4 text-sm sm:text-base text-[#242424] leading-relaxed">
        {t.pages.terms.paragraphs.map((p, idx) => (
          <p key={idx}>{p}</p>
        ))}
      </div>
    </div>
  );
};
