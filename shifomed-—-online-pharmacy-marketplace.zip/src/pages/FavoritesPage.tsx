import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, ShoppingBag, ArrowRight } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PRODUCTS } from '../data/products';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { ProductCard } from '../components/ProductCard';

export const FavoritesPage: React.FC = () => {
  const { t, favorites, addToCart, clearFavorites } = useApp();

  const favoriteProducts = PRODUCTS.filter((p) => favorites.includes(p.id));
  const addableProducts = favoriteProducts.filter((p) => p.inStock && !p.isPrescription);

  const handleAddAllToCart = () => {
    addableProducts.forEach((p) => addToCart(p.id, 1));
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10 py-8 sm:py-10">
      <Breadcrumbs
        items={[
          { label: t.nav.home, to: '/' },
          { label: t.favorites.title },
        ]}
      />

      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-6 mb-8 border-b border-[#E8E8E8]">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-[#171717] tracking-tight">
            {t.favorites.title}
          </h1>
          <p className="text-sm text-[#777777] mt-1.5">{t.favorites.subtitle}</p>
        </div>

        {favoriteProducts.length > 0 && (
          <div className="flex items-center gap-3">
            {addableProducts.length > 0 && (
              <button
                type="button"
                onClick={handleAddAllToCart}
                className="h-10 px-4 bg-[#171717] hover:bg-[#D71920] text-white text-xs font-semibold rounded-sm inline-flex items-center gap-2 transition-colors cursor-pointer whitespace-nowrap"
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>{t.favorites.addAllToCart}</span>
              </button>
            )}
            <button
              type="button"
              onClick={clearFavorites}
              className="h-10 px-4 border border-[#E8E8E8] hover:border-[#171717] text-xs font-semibold text-[#171717] rounded-sm transition-colors cursor-pointer whitespace-nowrap"
            >
              {t.favorites.clearAll}
            </button>
          </div>
        )}
      </div>

      {favoriteProducts.length === 0 ? (
        <div className="bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm p-12 text-center max-w-2xl mx-auto">
          <div className="w-12 h-12 bg-white border border-[#E8E8E8] rounded-sm flex items-center justify-center mx-auto mb-4 text-[#777777]">
            <Heart className="w-6 h-6" />
          </div>
          <h2 className="text-xl font-bold text-[#171717] mb-2">{t.favorites.emptyTitle}</h2>
          <p className="text-sm text-[#777777] mb-6">{t.favorites.emptyDesc}</p>
          <Link
            to="/catalog"
            className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-[#D71920] hover:bg-[#B5121B] text-white text-sm font-semibold rounded-sm transition-colors"
          >
            <span>{t.cart.continueShopping}</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {favoriteProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
};
