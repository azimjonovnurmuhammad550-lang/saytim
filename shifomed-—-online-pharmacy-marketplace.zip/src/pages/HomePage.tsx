import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  ShieldCheck,
  ThermometerSnowflake,
  Stethoscope,
  Store,
  CheckCircle2,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CATEGORIES, IMAGES } from '../data/categories';
import { PRODUCTS } from '../data/products';
import { ProductCard } from '../components/ProductCard';
import { SafeImage } from '../components/SafeImage';

type CollectionTab = 'popular' | 'offers' | 'bestsellers';

export const HomePage: React.FC = () => {
  const { language, t, showToast } = useApp();
  const [activeTab, setActiveTab] = useState<CollectionTab>('popular');
  const [email, setEmail] = useState('');
  const [emailError, setEmailError] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const tabProducts = useMemo(() => {
    if (activeTab === 'offers') {
      return PRODUCTS.filter((p) => p.previousPriceUZS && p.previousPriceUZS > p.priceUZS).slice(0, 8);
    }
    if (activeTab === 'bestsellers') {
      return PRODUCTS.filter((p) => p.isBestseller).slice(0, 8);
    }
    return [...PRODUCTS].sort((a, b) => b.popularity - a.popularity).slice(0, 8);
  }, [activeTab]);

  const benefitIcons = [ShieldCheck, ThermometerSnowflake, Stethoscope, Store];

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = email.trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(trimmed)) {
      setEmailError(t.home.newsletter.invalidEmail);
      return;
    }
    setEmailError('');
    setSubscribed(true);
    setEmail('');
    showToast(t.home.newsletter.success, 'success');
  };

  return (
    <div>
      {/* 1. Hero Split Section */}
      <section className="border-b border-[#E8E8E8] bg-white">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10 py-10 lg:py-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
            <div className="lg:col-span-6 flex flex-col justify-center">
              <p className="text-xs font-semibold tracking-wide text-[#D71920] mb-3">
                {t.hero.eyebrow}
              </p>
              <h1
                className="font-display font-extrabold text-[#171717] tracking-tight leading-[1.1] mb-5"
                style={{ fontSize: 'clamp(2rem, 3.6vw, 3.25rem)', textWrap: 'balance' }}
              >
                {t.hero.title}
              </h1>
              <p className="text-base sm:text-lg text-[#242424] leading-relaxed max-w-xl mb-8">
                {t.hero.subtitle}
              </p>
              <div className="flex flex-wrap items-center gap-3">
                <Link
                  to="/catalog"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-[#D71920] hover:bg-[#B5121B] text-white text-sm font-semibold rounded-sm transition-colors whitespace-nowrap"
                >
                  <span>{t.hero.primaryCta}</span>
                  <ArrowRight className="w-4 h-4" aria-hidden="true" />
                </Link>
                <Link
                  to="/catalog?discounted=true"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-white border border-[#171717] hover:bg-[#171717] hover:text-white text-[#171717] text-sm font-semibold rounded-sm transition-colors whitespace-nowrap"
                >
                  {t.hero.secondaryCta}
                </Link>
              </div>
            </div>

            <div className="lg:col-span-6">
              <div className="aspect-[16/10] lg:aspect-auto lg:h-full min-h-[280px] bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm overflow-hidden">
                <SafeImage
                  src={IMAGES.hero}
                  alt={t.hero.title}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>

          {/* Full-width 4-Column Trust Strip below Hero Split */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mt-10 pt-8 border-t border-[#E8E8E8]">
            {t.hero.trustMetrics.map((metric, idx) => (
              <div key={idx} className="flex flex-col">
                <span className="font-display text-xl sm:text-2xl font-extrabold text-[#171717] tabular-nums">
                  {metric.value}
                </span>
                <span className="text-xs sm:text-sm text-[#777777] mt-1">{metric.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 2. Featured Categories */}
      <section className="py-14 lg:py-16 bg-[#F7F7F7] border-b border-[#E8E8E8]">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
            <div>
              <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#171717] tracking-tight">
                {t.home.categoriesTitle}
              </h2>
              <p className="text-sm text-[#777777] mt-1.5">{t.home.categoriesSubtitle}</p>
            </div>
            <Link
              to="/catalog"
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#D71920] hover:text-[#B5121B] whitespace-nowrap"
            >
              <span>{t.home.viewCatalog}</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </Link>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
            {CATEGORIES.map((category) => {
              const count = PRODUCTS.filter((p) => p.category === category.id).length;
              return (
                <Link
                  key={category.id}
                  to={`/catalog?category=${category.id}`}
                  className="group bg-white border border-[#E8E8E8] hover:border-[#171717] rounded-sm overflow-hidden flex flex-col transition-all duration-150 hover:-translate-y-0.5"
                >
                  <div className="aspect-[4/3] bg-[#F7F7F7] border-b border-[#E8E8E8] overflow-hidden">
                    <SafeImage
                      src={category.image}
                      alt={category.name[language]}
                      className="w-full h-full object-cover transition-transform duration-200 group-hover:scale-[1.03]"
                    />
                  </div>
                  <div className="p-4 flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <h3 className="text-sm sm:text-base font-semibold text-[#171717] truncate group-hover:text-[#D71920] transition-colors">
                        {category.name[language]}
                      </h3>
                      <p className="text-xs text-[#777777] mt-0.5 tabular-nums">
                        {count} {t.cart.itemsCount}
                      </p>
                    </div>
                    <ArrowRight
                      className="w-4 h-4 text-[#777777] group-hover:text-[#D71920] shrink-0 transition-colors"
                      aria-hidden="true"
                    />
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* 3. Tabbed Collection: Popular / Special Offers / Best Sellers */}
      <section className="py-14 lg:py-16 bg-white border-b border-[#E8E8E8]">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <div
              role="tablist"
              aria-label="Product collections"
              className="inline-flex items-center p-1 bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm overflow-x-auto max-w-full"
            >
              {(
                [
                  { id: 'popular', label: t.home.collectionTabs.popular },
                  { id: 'offers', label: t.home.collectionTabs.offers },
                  { id: 'bestsellers', label: t.home.collectionTabs.bestsellers },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  role="tab"
                  aria-selected={activeTab === tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-sm transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    activeTab === tab.id
                      ? 'bg-[#171717] text-white'
                      : 'text-[#242424] hover:text-[#171717]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <Link
              to={activeTab === 'offers' ? '/catalog?discounted=true' : '/catalog'}
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#D71920] hover:text-[#B5121B] whitespace-nowrap"
            >
              <span>{t.home.viewCatalog}</span>
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {tabProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* 4. Promotional Wellness Banner */}
      <section className="py-14 lg:py-16 bg-[#F7F7F7] border-b border-[#E8E8E8]">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10">
          <div className="bg-white border border-[#E8E8E8] rounded-sm overflow-hidden grid grid-cols-1 lg:grid-cols-12 items-stretch">
            <div className="lg:col-span-6 p-8 sm:p-12 flex flex-col justify-center">
              <span className="text-xs font-semibold text-[#D71920] mb-3">
                {t.home.promo.eyebrow}
              </span>
              <h2
                className="font-display text-2xl sm:text-3xl font-extrabold text-[#171717] tracking-tight mb-4"
                style={{ textWrap: 'balance' }}
              >
                {t.home.promo.title}
              </h2>
              <p className="text-sm sm:text-base text-[#242424] leading-relaxed mb-7 max-w-lg">
                {t.home.promo.subtitle}
              </p>
              <div>
                <Link
                  to="/catalog?category=vitamins"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-[#171717] hover:bg-[#D71920] text-white text-sm font-semibold rounded-sm transition-colors whitespace-nowrap"
                >
                  <span>{t.home.promo.cta}</span>
                  <ArrowRight className="w-4 h-4" aria-hidden="true" />
                </Link>
              </div>
            </div>
            <div className="lg:col-span-6 aspect-[16/9] lg:aspect-auto min-h-[260px] bg-[#F7F7F7]">
              <SafeImage
                src={IMAGES.promo}
                alt={t.home.promo.title}
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* 5. Benefits & Customer Trust */}
      <section className="py-14 lg:py-16 bg-white border-b border-[#E8E8E8]">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10">
          <div className="max-w-2xl mb-10">
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-[#171717] tracking-tight">
              {t.home.benefitsTitle}
            </h2>
            <p className="text-sm sm:text-base text-[#777777] mt-2">
              {t.home.benefitsSubtitle}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 pb-14 border-b border-[#E8E8E8]">
            {t.home.benefits.map((item, idx) => {
              const Icon = benefitIcons[idx] ?? ShieldCheck;
              return (
                <div
                  key={idx}
                  className="p-6 bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm flex flex-col"
                >
                  <div className="w-10 h-10 bg-white border border-[#E8E8E8] rounded-sm flex items-center justify-center text-[#D71920] mb-4">
                    <Icon className="w-5 h-5" aria-hidden="true" />
                  </div>
                  <h3 className="text-base font-bold text-[#171717] mb-2">{item.title}</h3>
                  <p className="text-sm text-[#242424] leading-relaxed">{item.desc}</p>
                </div>
              );
            })}
          </div>

          {/* Adjacent Trust Proof */}
          <div className="pt-14">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
              <div>
                <h2 className="font-display text-2xl font-bold text-[#171717] tracking-tight">
                  {t.home.trustTitle}
                </h2>
                <p className="text-sm font-medium text-[#242424] mt-1.5 tabular-nums">
                  {t.home.trustMetricLabel}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {t.home.testimonials.map((review, idx) => (
                <blockquote
                  key={idx}
                  className="p-6 bg-white border border-[#E8E8E8] rounded-sm flex flex-col justify-between"
                >
                  <p className="text-sm text-[#242424] leading-relaxed mb-6">
                    “{review.quote}”
                  </p>
                  <footer className="pt-4 border-t border-[#E8E8E8]">
                    <div className="text-sm font-semibold text-[#171717]">{review.name}</div>
                    <div className="text-xs text-[#777777] mt-0.5">{review.role}</div>
                  </footer>
                </blockquote>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 6. Newsletter Subscription */}
      <section className="py-14 bg-[#F7F7F7]">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10">
          <div className="bg-white border border-[#E8E8E8] rounded-sm p-8 sm:p-10 flex flex-col lg:flex-row lg:items-center justify-between gap-8">
            <div className="max-w-xl">
              <h2 className="font-display text-xl sm:text-2xl font-bold text-[#171717] tracking-tight">
                {t.home.newsletter.title}
              </h2>
              <p className="text-sm text-[#777777] mt-2">{t.home.newsletter.subtitle}</p>
            </div>

            <div className="w-full lg:max-w-md">
              {subscribed ? (
                <div className="flex items-center gap-2.5 p-4 bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm text-sm font-medium text-[#171717]">
                  <CheckCircle2 className="w-5 h-5 text-[#D71920] shrink-0" />
                  <span>{t.home.newsletter.success}</span>
                </div>
              ) : (
                <form onSubmit={handleNewsletterSubmit} noValidate>
                  <div className="flex flex-col sm:flex-row gap-2.5">
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => {
                        setEmail(e.target.value);
                        if (emailError) setEmailError('');
                      }}
                      placeholder={t.home.newsletter.placeholder}
                      aria-label={t.home.newsletter.placeholder}
                      className="flex-1 h-11 px-4 text-sm bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm text-[#171717] placeholder:text-[#777777] focus:bg-white focus:border-[#171717] focus:outline-none"
                    />
                    <button
                      type="submit"
                      className="h-11 px-6 bg-[#D71920] hover:bg-[#B5121B] text-white text-sm font-semibold rounded-sm transition-colors whitespace-nowrap cursor-pointer"
                    >
                      {t.home.newsletter.submit}
                    </button>
                  </div>
                  {emailError && (
                    <p className="text-xs text-[#D71920] mt-2 font-medium">{emailError}</p>
                  )}
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
