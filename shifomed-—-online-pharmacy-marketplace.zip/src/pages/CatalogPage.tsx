import React, { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { SlidersHorizontal, X, Search } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CATEGORIES } from '../data/categories';
import { PRODUCTS } from '../data/products';
import { CategoryId } from '../types';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { ProductCard } from '../components/ProductCard';

type SortOption = 'popular' | 'priceAsc' | 'priceDesc' | 'newest';

const PAGE_SIZE = 12;

export const CatalogPage: React.FC = () => {
  const { language, t } = useApp();
  const [searchParams, setSearchParams] = useSearchParams();

  const initialCategory = (searchParams.get('category') as CategoryId | null) ?? 'all';
  const initialQuery = searchParams.get('q') ?? '';
  const initialDiscounted = searchParams.get('discounted') === 'true';

  const [selectedCategory, setSelectedCategory] = useState<CategoryId | 'all'>(initialCategory);
  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [onlyInStock, setOnlyInStock] = useState(false);
  const [onlyDiscounted, setOnlyDiscounted] = useState(initialDiscounted);
  const [onlyOtc, setOnlyOtc] = useState(false);
  const [sortBy, setSortBy] = useState<SortOption>('popular');
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  // Sync URL query params into local filter state when user clicks nav links
  useEffect(() => {
    const cat = searchParams.get('category') as CategoryId | null;
    const q = searchParams.get('q') ?? '';
    const disc = searchParams.get('discounted') === 'true';
    setSelectedCategory(cat && CATEGORIES.some((c) => c.id === cat) ? cat : 'all');
    setSearchQuery(q);
    setOnlyDiscounted(disc);
    setVisibleCount(PAGE_SIZE);
  }, [searchParams]);

  const allBrands = useMemo(
    () => Array.from(new Set(PRODUCTS.map((p) => p.brand))).sort(),
    []
  );

  const filteredProducts = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const min = minPrice ? Number(minPrice) : null;
    const max = maxPrice ? Number(maxPrice) : null;

    let list = PRODUCTS.filter((p) => {
      if (selectedCategory !== 'all' && p.category !== selectedCategory) return false;
      if (onlyInStock && !p.inStock) return false;
      if (onlyDiscounted && !(p.previousPriceUZS && p.previousPriceUZS > p.priceUZS)) return false;
      if (onlyOtc && p.isPrescription) return false;
      if (selectedBrands.length > 0 && !selectedBrands.includes(p.brand)) return false;
      if (min !== null && !Number.isNaN(min) && p.priceUZS < min) return false;
      if (max !== null && !Number.isNaN(max) && p.priceUZS > max) return false;

      if (q) {
        const matches =
          p.name[language].toLowerCase().includes(q) ||
          p.name.uz.toLowerCase().includes(q) ||
          p.name.en.toLowerCase().includes(q) ||
          p.name.ru.toLowerCase().includes(q) ||
          p.brand.toLowerCase().includes(q) ||
          p.description[language].toLowerCase().includes(q) ||
          p.sku.toLowerCase().includes(q);
        if (!matches) return false;
      }

      return true;
    });

    list = [...list].sort((a, b) => {
      if (sortBy === 'priceAsc') return a.priceUZS - b.priceUZS;
      if (sortBy === 'priceDesc') return b.priceUZS - a.priceUZS;
      if (sortBy === 'newest') return Number(Boolean(b.isNew)) - Number(Boolean(a.isNew)) || b.popularity - a.popularity;
      return b.popularity - a.popularity;
    });

    return list;
  }, [
    selectedCategory,
    onlyInStock,
    onlyDiscounted,
    onlyOtc,
    selectedBrands,
    minPrice,
    maxPrice,
    searchQuery,
    language,
    sortBy,
  ]);

  const visibleProducts = filteredProducts.slice(0, visibleCount);

  const toggleBrand = (brand: string) => {
    setSelectedBrands((prev) =>
      prev.includes(brand) ? prev.filter((b) => b !== brand) : [...prev, brand]
    );
    setVisibleCount(PAGE_SIZE);
  };

  const handleCategoryChange = (cat: CategoryId | 'all') => {
    setSelectedCategory(cat);
    setVisibleCount(PAGE_SIZE);
    const next = new URLSearchParams(searchParams);
    if (cat === 'all') {
      next.delete('category');
    } else {
      next.set('category', cat);
    }
    setSearchParams(next, { replace: true });
  };

  const handleClearFilters = () => {
    setSelectedCategory('all');
    setSearchQuery('');
    setMinPrice('');
    setMaxPrice('');
    setSelectedBrands([]);
    setOnlyInStock(false);
    setOnlyDiscounted(false);
    setOnlyOtc(false);
    setSortBy('popular');
    setVisibleCount(PAGE_SIZE);
    setSearchParams({}, { replace: true });
  };

  const renderFiltersPanel = () => (
    <div className="space-y-6">
      {/* Search inside Catalog */}
      <div>
        <label htmlFor="catalog-search" className="block text-xs font-semibold text-[#171717] mb-2">
          {t.search.submit}
        </label>
        <div className="relative">
          <Search className="w-4 h-4 text-[#777777] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            id="catalog-search"
            type="search"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setVisibleCount(PAGE_SIZE);
            }}
            placeholder={t.search.mobilePlaceholder}
            className="w-full h-10 pl-9 pr-3 text-sm bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm text-[#171717] focus:bg-white focus:border-[#171717] focus:outline-none"
          />
        </div>
      </div>

      {/* Category Filter */}
      <div className="pt-5 border-t border-[#E8E8E8]">
        <h3 className="text-xs font-semibold text-[#171717] mb-3">
          {t.catalog.categoryFilter}
        </h3>
        <div className="space-y-1">
          <button
            type="button"
            onClick={() => handleCategoryChange('all')}
            className={`w-full text-left px-2.5 py-2 text-sm rounded-sm flex items-center justify-between transition-colors cursor-pointer ${
              selectedCategory === 'all'
                ? 'bg-[#171717] text-white font-semibold'
                : 'text-[#242424] hover:bg-[#F7F7F7]'
            }`}
          >
            <span>{t.catalog.allCategories}</span>
            <span className="text-xs opacity-75 tabular-nums">{PRODUCTS.length}</span>
          </button>
          {CATEGORIES.map((cat) => {
            const count = PRODUCTS.filter((p) => p.category === cat.id).length;
            const active = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => handleCategoryChange(cat.id)}
                className={`w-full text-left px-2.5 py-2 text-sm rounded-sm flex items-center justify-between transition-colors cursor-pointer ${
                  active
                    ? 'bg-[#171717] text-white font-semibold'
                    : 'text-[#242424] hover:bg-[#F7F7F7]'
                }`}
              >
                <span className="truncate pr-2">{cat.name[language]}</span>
                <span className="text-xs opacity-75 tabular-nums shrink-0">{count}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Price Range */}
      <div className="pt-5 border-t border-[#E8E8E8]">
        <h3 className="text-xs font-semibold text-[#171717] mb-3">{t.catalog.priceRange}</h3>
        <div className="grid grid-cols-2 gap-2">
          <input
            type="number"
            min="0"
            step="5000"
            value={minPrice}
            onChange={(e) => {
              setMinPrice(e.target.value);
              setVisibleCount(PAGE_SIZE);
            }}
            placeholder={t.catalog.minPrice}
            aria-label={t.catalog.minPrice}
            className="h-9 px-2.5 text-sm bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm text-[#171717] tabular-nums focus:bg-white focus:border-[#171717] focus:outline-none"
          />
          <input
            type="number"
            min="0"
            step="5000"
            value={maxPrice}
            onChange={(e) => {
              setMaxPrice(e.target.value);
              setVisibleCount(PAGE_SIZE);
            }}
            placeholder={t.catalog.maxPrice}
            aria-label={t.catalog.maxPrice}
            className="h-9 px-2.5 text-sm bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm text-[#171717] tabular-nums focus:bg-white focus:border-[#171717] focus:outline-none"
          />
        </div>
      </div>

      {/* Availability & Dispensing */}
      <div className="pt-5 border-t border-[#E8E8E8]">
        <h3 className="text-xs font-semibold text-[#171717] mb-3">
          {t.catalog.availabilityFilter}
        </h3>
        <div className="space-y-2.5 text-sm text-[#242424]">
          <label className="flex items-center gap-2.5 cursor-pointer">
            <input
              type="checkbox"
              checked={onlyInStock}
              onChange={(e) => {
                setOnlyInStock(e.target.checked);
                setVisibleCount(PAGE_SIZE);
              }}
              className="w-4 h-4 accent-[#D71920] rounded-sm"
            />
            <span>{t.catalog.onlyInStock}</span>
          </label>
          <label className="flex items-center gap-2.5 cursor-pointer">
            <input
              type="checkbox"
              checked={onlyDiscounted}
              onChange={(e) => {
                setOnlyDiscounted(e.target.checked);
                setVisibleCount(PAGE_SIZE);
              }}
              className="w-4 h-4 accent-[#D71920] rounded-sm"
            />
            <span>{t.catalog.onlyDiscounted}</span>
          </label>
          <label className="flex items-center gap-2.5 cursor-pointer">
            <input
              type="checkbox"
              checked={onlyOtc}
              onChange={(e) => {
                setOnlyOtc(e.target.checked);
                setVisibleCount(PAGE_SIZE);
              }}
              className="w-4 h-4 accent-[#D71920] rounded-sm"
            />
            <span>{t.catalog.onlyOtc}</span>
          </label>
        </div>
      </div>

      {/* Brands */}
      <div className="pt-5 border-t border-[#E8E8E8]">
        <h3 className="text-xs font-semibold text-[#171717] mb-3">{t.catalog.brandFilter}</h3>
        <div className="space-y-2 text-sm text-[#242424] max-h-56 overflow-y-auto pr-1">
          {allBrands.map((brand) => (
            <label key={brand} className="flex items-center gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={selectedBrands.includes(brand)}
                onChange={() => toggleBrand(brand)}
                className="w-4 h-4 accent-[#D71920] rounded-sm"
              />
              <span>{brand}</span>
            </label>
          ))}
        </div>
      </div>

      <button
        type="button"
        onClick={handleClearFilters}
        className="w-full py-2.5 px-4 text-xs font-semibold border border-[#E8E8E8] hover:border-[#171717] text-[#171717] rounded-sm transition-colors cursor-pointer"
      >
        {t.catalog.clearFilters}
      </button>
    </div>
  );

  const countText = t.catalog.showingCount
    .replace('{shown}', String(visibleProducts.length))
    .replace('{total}', String(filteredProducts.length));

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10 py-8 sm:py-10">
      <Breadcrumbs
        items={[
          { label: t.nav.home, to: '/' },
          { label: t.nav.catalog },
        ]}
      />

      <div className="pb-6 mb-8 border-b border-[#E8E8E8] flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-[#171717] tracking-tight">
            {selectedCategory !== 'all'
              ? CATEGORIES.find((c) => c.id === selectedCategory)?.name[language] ?? t.catalog.title
              : t.catalog.title}
          </h1>
          <p className="text-sm text-[#777777] mt-1.5">{t.catalog.subtitle}</p>
        </div>

        <div className="flex items-center flex-wrap gap-3">
          <button
            type="button"
            onClick={() => setMobileFiltersOpen(true)}
            className="lg:hidden h-10 px-4 inline-flex items-center gap-2 border border-[#E8E8E8] bg-white hover:border-[#171717] rounded-sm text-xs font-semibold text-[#171717]"
          >
            <SlidersHorizontal className="w-4 h-4" />
            <span>{t.catalog.filters}</span>
          </button>

          <div className="flex items-center gap-2">
            <label htmlFor="sort-select" className="text-xs text-[#777777] whitespace-nowrap">
              {t.catalog.sortBy}
            </label>
            <select
              id="sort-select"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
              className="h-10 px-3 text-xs sm:text-sm font-medium bg-white border border-[#E8E8E8] rounded-sm text-[#171717] focus:border-[#171717] focus:outline-none cursor-pointer"
            >
              <option value="popular">{t.catalog.sortOptions.popular}</option>
              <option value="priceAsc">{t.catalog.sortOptions.priceAsc}</option>
              <option value="priceDesc">{t.catalog.sortOptions.priceDesc}</option>
              <option value="newest">{t.catalog.sortOptions.newest}</option>
            </select>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Desktop Sidebar */}
        <aside className="hidden lg:block lg:col-span-3 bg-white border border-[#E8E8E8] rounded-sm p-5 sticky top-24">
          {renderFiltersPanel()}
        </aside>

        {/* Product Grid Area */}
        <div className="lg:col-span-9">
          <div className="flex items-center justify-between gap-4 mb-5 text-xs text-[#777777]">
            <span className="tabular-nums">{countText}</span>
            {(selectedCategory !== 'all' ||
              searchQuery ||
              minPrice ||
              maxPrice ||
              selectedBrands.length > 0 ||
              onlyInStock ||
              onlyDiscounted ||
              onlyOtc) && (
              <button
                type="button"
                onClick={handleClearFilters}
                className="text-[#D71920] hover:underline font-semibold cursor-pointer"
              >
                {t.catalog.clearFilters}
              </button>
            )}
          </div>

          {filteredProducts.length === 0 ? (
            <div className="bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm p-12 text-center">
              <h2 className="text-lg font-bold text-[#171717] mb-2">{t.catalog.emptyTitle}</h2>
              <p className="text-sm text-[#777777] max-w-md mx-auto mb-6">{t.catalog.emptyDesc}</p>
              <button
                type="button"
                onClick={handleClearFilters}
                className="px-5 py-2.5 bg-[#171717] hover:bg-[#D71920] text-white text-sm font-semibold rounded-sm transition-colors cursor-pointer"
              >
                {t.catalog.clearFilters}
              </button>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                {visibleProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>

              {visibleCount < filteredProducts.length && (
                <div className="mt-10 flex justify-center">
                  <button
                    type="button"
                    onClick={() => setVisibleCount((prev) => prev + PAGE_SIZE)}
                    className="px-8 py-3 bg-white border border-[#171717] hover:bg-[#171717] hover:text-white text-[#171717] text-sm font-semibold rounded-sm transition-colors cursor-pointer"
                  >
                    {t.catalog.loadMore}
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Mobile Filter Drawer */}
      {mobileFiltersOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex justify-end">
          <div
            className="fixed inset-0 bg-black/50"
            onClick={() => setMobileFiltersOpen(false)}
            aria-hidden="true"
          />
          <div className="relative w-80 max-w-[85vw] bg-white h-full overflow-y-auto p-5 shadow-xl">
            <div className="flex items-center justify-between pb-4 mb-5 border-b border-[#E8E8E8]">
              <h2 className="text-base font-bold text-[#171717]">{t.catalog.filters}</h2>
              <button
                type="button"
                onClick={() => setMobileFiltersOpen(false)}
                aria-label={t.nav.close}
                className="w-9 h-9 flex items-center justify-center text-[#171717]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            {renderFiltersPanel()}
            <button
              type="button"
              onClick={() => setMobileFiltersOpen(false)}
              className="mt-6 w-full py-3 bg-[#D71920] text-white text-sm font-semibold rounded-sm"
            >
              {t.catalog.applyFilters}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
