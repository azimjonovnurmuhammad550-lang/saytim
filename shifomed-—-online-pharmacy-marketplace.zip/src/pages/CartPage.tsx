import React from 'react';
import { Link } from 'react-router-dom';
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight, FileText } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { DELIVERY_FEES, formatUZS } from '../i18n/translations';
import { DeliveryMethodId } from '../types';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { SafeImage } from '../components/SafeImage';

export const CartPage: React.FC = () => {
  const {
    language,
    t,
    cartProducts,
    cartCount,
    subtotalUZS,
    discountSavingsUZS,
    hasPrescriptionItemsInCart,
    deliveryMethod,
    setDeliveryMethod,
    deliveryCostUZS,
    totalUZS,
    updateCartQuantity,
    removeFromCart,
    clearCart,
  } = useApp();

  const remainingForFreeStandard = Math.max(
    0,
    DELIVERY_FEES.freeStandardThreshold - subtotalUZS
  );
  const freeProgressPercent = Math.min(
    100,
    Math.round((subtotalUZS / DELIVERY_FEES.freeStandardThreshold) * 100)
  );

  const deliveryOptions: { id: DeliveryMethodId; priceText: string }[] = [
    {
      id: 'standard',
      priceText:
        subtotalUZS >= DELIVERY_FEES.freeStandardThreshold
          ? t.cart.free
          : formatUZS(DELIVERY_FEES.standard, language),
    },
    {
      id: 'express',
      priceText: formatUZS(DELIVERY_FEES.express, language),
    },
    {
      id: 'pickup',
      priceText: t.cart.free,
    },
  ];

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10 py-8 sm:py-10">
      <Breadcrumbs
        items={[
          { label: t.nav.home, to: '/' },
          { label: t.cart.title },
        ]}
      />

      <div className="flex items-end justify-between gap-4 pb-6 mb-8 border-b border-[#E8E8E8]">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-extrabold text-[#171717] tracking-tight">
            {t.cart.title}
          </h1>
          {cartCount > 0 && (
            <p className="text-sm text-[#777777] mt-1 tabular-nums">
              {cartCount} {t.cart.itemsCount}
            </p>
          )}
        </div>
        {cartProducts.length > 0 && (
          <button
            type="button"
            onClick={clearCart}
            className="text-xs font-semibold text-[#777777] hover:text-[#D71920] transition-colors cursor-pointer"
          >
            {t.cart.clearCart}
          </button>
        )}
      </div>

      {cartProducts.length === 0 ? (
        <div className="bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm p-12 text-center max-w-2xl mx-auto">
          <div className="w-12 h-12 bg-white border border-[#E8E8E8] rounded-sm flex items-center justify-center mx-auto mb-4 text-[#777777]">
            <ShoppingBag className="w-6 h-6" />
          </div>
          <h2 className="text-xl font-bold text-[#171717] mb-2">{t.cart.emptyTitle}</h2>
          <p className="text-sm text-[#777777] mb-6">{t.cart.emptyDesc}</p>
          <Link
            to="/catalog"
            className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-[#D71920] hover:bg-[#B5121B] text-white text-sm font-semibold rounded-sm transition-colors"
          >
            <span>{t.cart.continueShopping}</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left: Cart Items */}
          <div className="lg:col-span-8 space-y-4">
            {/* Free Delivery Threshold Progress */}
            <div className="p-4 bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm">
              <div className="text-xs sm:text-sm font-medium text-[#171717] mb-2">
                {remainingForFreeStandard > 0
                  ? t.cart.freeDeliveryHint.replace(
                      '{amount}',
                      formatUZS(remainingForFreeStandard, language)
                    )
                  : t.cart.freeDeliveryUnlocked}
              </div>
              <div className="w-full h-1.5 bg-[#E8E8E8] rounded-sm overflow-hidden">
                <div
                  className="h-full bg-[#D71920] transition-all duration-300"
                  style={{ width: `${freeProgressPercent}%` }}
                />
              </div>
            </div>

            {hasPrescriptionItemsInCart && (
              <div className="p-4 bg-white border border-[#D71920]/40 rounded-sm flex items-start gap-2.5 text-xs sm:text-sm text-[#242424]">
                <FileText className="w-4 h-4 text-[#D71920] mt-0.5 shrink-0" />
                <span>{t.cart.rxCartNotice}</span>
              </div>
            )}

            <div className="border border-[#E8E8E8] rounded-sm divide-y divide-[#E8E8E8] bg-white">
              {cartProducts.map(({ product, quantity }) => (
                <div
                  key={product.id}
                  className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center gap-4"
                >
                  <Link
                    to={`/product/${product.id}`}
                    className="w-24 h-20 bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm overflow-hidden shrink-0"
                  >
                    <SafeImage
                      src={product.image}
                      alt={product.name[language]}
                      className="w-full h-full object-cover"
                    />
                  </Link>

                  <div className="flex-1 min-w-0">
                    <div className="text-xs text-[#777777] mb-1">
                      {product.brand}
                      {product.isPrescription && (
                        <>
                          <span className="mx-1.5" aria-hidden="true">·</span>
                          <span className="text-[#D71920] font-semibold">
                            {t.product.prescriptionRequired}
                          </span>
                        </>
                      )}
                    </div>
                    <Link
                      to={`/product/${product.id}`}
                      className="text-sm sm:text-base font-semibold text-[#171717] hover:text-[#D71920] transition-colors line-clamp-2"
                    >
                      {product.name[language]}
                    </Link>
                    <div className="text-xs text-[#777777] mt-1 tabular-nums">
                      {formatUZS(product.priceUZS, language)} × {quantity}
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-4 pt-2 sm:pt-0 border-t sm:border-t-0 border-[#E8E8E8]">
                    <div className="inline-flex items-center border border-[#E8E8E8] rounded-sm h-9 px-1 bg-white">
                      <button
                        type="button"
                        aria-label="Decrease quantity"
                        onClick={() => updateCartQuantity(product.id, quantity - 1)}
                        className="w-7 h-7 flex items-center justify-center text-[#171717] hover:bg-[#F7F7F7] rounded-sm cursor-pointer"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="w-8 text-center text-xs font-bold text-[#171717] tabular-nums">
                        {quantity}
                      </span>
                      <button
                        type="button"
                        aria-label="Increase quantity"
                        disabled={quantity >= product.stockCount}
                        onClick={() => updateCartQuantity(product.id, quantity + 1)}
                        className="w-7 h-7 flex items-center justify-center text-[#171717] disabled:text-[#777777] hover:bg-[#F7F7F7] rounded-sm cursor-pointer"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="text-right min-w-[110px]">
                      <div className="text-sm sm:text-base font-bold text-[#171717] tabular-nums">
                        {formatUZS(product.priceUZS * quantity, language)}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => removeFromCart(product.id)}
                      aria-label={t.cart.remove}
                      className="p-2 text-[#777777] hover:text-[#D71920] transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div>
              <Link
                to="/catalog"
                className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#171717] hover:text-[#D71920] transition-colors"
              >
                {t.cart.continueShopping}
              </Link>
            </div>
          </div>

          {/* Right: Order Summary */}
          <aside className="lg:col-span-4 bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm p-6 sticky top-24">
            <h2 className="font-display text-lg font-bold text-[#171717] pb-4 mb-4 border-b border-[#E8E8E8]">
              {t.cart.summaryTitle}
            </h2>

            {/* Delivery Selector */}
            <div className="mb-5">
              <div className="text-xs font-semibold text-[#171717] mb-2.5">
                {t.cart.deliveryLabel}
              </div>
              <div className="space-y-2">
                {deliveryOptions.map((opt) => (
                  <label
                    key={opt.id}
                    className={`flex items-start justify-between gap-2 p-3 border rounded-sm cursor-pointer transition-colors ${
                      deliveryMethod === opt.id
                        ? 'bg-white border-[#171717]'
                        : 'bg-white/60 border-[#E8E8E8] hover:border-[#777777]'
                    }`}
                  >
                    <div className="flex items-start gap-2.5">
                      <input
                        type="radio"
                        name="cart-delivery"
                        checked={deliveryMethod === opt.id}
                        onChange={() => setDeliveryMethod(opt.id)}
                        className="mt-0.5 accent-[#D71920]"
                      />
                      <div>
                        <div className="text-xs font-semibold text-[#171717]">
                          {t.deliveryMethods[opt.id].title}
                        </div>
                        <div className="text-[11px] text-[#777777] mt-0.5">
                          {t.deliveryMethods[opt.id].desc}
                        </div>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-[#171717] tabular-nums whitespace-nowrap">
                      {opt.priceText}
                    </span>
                  </label>
                ))}
              </div>
            </div>

            <dl className="space-y-2.5 text-sm pt-4 border-t border-[#E8E8E8]">
              <div className="flex items-center justify-between">
                <dt className="text-[#777777]">{t.cart.subtotal}</dt>
                <dd className="font-semibold text-[#171717] tabular-nums">
                  {formatUZS(subtotalUZS, language)}
                </dd>
              </div>
              {discountSavingsUZS > 0 && (
                <div className="flex items-center justify-between">
                  <dt className="text-[#777777]">{t.cart.discount}</dt>
                  <dd className="font-semibold text-[#D71920] tabular-nums">
                    -{formatUZS(discountSavingsUZS, language)}
                  </dd>
                </div>
              )}
              <div className="flex items-center justify-between">
                <dt className="text-[#777777]">{t.cart.deliveryCost}</dt>
                <dd className="font-semibold text-[#171717] tabular-nums">
                  {deliveryCostUZS === 0 ? t.cart.free : formatUZS(deliveryCostUZS, language)}
                </dd>
              </div>
              <div className="flex items-center justify-between pt-3 border-t border-[#E8E8E8] text-base font-extrabold text-[#171717]">
                <dt>{t.cart.total}</dt>
                <dd className="tabular-nums">{formatUZS(totalUZS, language)}</dd>
              </div>
            </dl>

            <Link
              to="/checkout"
              className="mt-6 w-full h-12 bg-[#D71920] hover:bg-[#B5121B] text-white text-sm font-semibold rounded-sm flex items-center justify-center gap-2 transition-colors"
            >
              <span>{t.cart.proceedCheckout}</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </aside>
        </div>
      )}
    </div>
  );
};
