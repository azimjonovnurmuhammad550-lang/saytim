import { Category } from '../types';

export const IMAGES = {
  hero: '/src/assets/images/hero_pharmacy_modern_1795698288849.jpg',
  promo: '/src/assets/images/promo_wellness_vitamins_1795698289410.jpg',
  medicines: '/src/assets/images/prod_medicines_box_1795698289463.jpg',
  vitamins: '/src/assets/images/prod_vitamins_bottle_1795698289494.jpg',
  skincare: '/src/assets/images/prod_derma_skincare_1795698289862.jpg',
  devices: '/src/assets/images/prod_medical_device_1795698290236.jpg',
  baby: '/src/assets/images/prod_baby_hygiene_1795698289796.jpg',
  firstAid: '/src/assets/images/prod_first_aid_kit_1795698290108.jpg',
} as const;

export const CATEGORIES: Category[] = [
  {
    id: 'medicines',
    name: {
      uz: 'Dori vositalari',
      en: 'Medicines',
      ru: 'Лекарственные средства',
    },
    description: {
      uz: 'Sertifikatlangan og‘riq qoldiruvchi, shamollash va terapiya vositalari',
      en: 'Certified pain relief, cold care, and general therapy medicines',
      ru: 'Сертифицированные препараты для обезболивания и базовой терапии',
    },
    image: IMAGES.medicines,
  },
  {
    id: 'vitamins',
    name: {
      uz: 'Vitaminlar va qo‘shimchalar',
      en: 'Vitamins & Supplements',
      ru: 'Витамины и добавки',
    },
    description: {
      uz: 'Immunitet, energiya va kundalik muvozanat uchun komplekslar',
      en: 'Daily complexes for immunity, energy, and micronutrient balance',
      ru: 'Комплексы для иммунитета, энергии и ежедневного баланса',
    },
    image: IMAGES.vitamins,
  },
  {
    id: 'personal-care',
    name: {
      uz: 'Shaxsiy parvarish',
      en: 'Personal Care',
      ru: 'Личный уход',
    },
    description: {
      uz: 'Dermatologik teri, soch va sezgir parvarish vositalari',
      en: 'Dermatological skincare, hair care, and gentle daily formulas',
      ru: 'Дерматологический уход за кожей, волосами и чувствительной кожей',
    },
    image: IMAGES.skincare,
  },
  {
    id: 'baby-care',
    name: {
      uz: 'Bolalar parvarishi',
      en: 'Baby Care',
      ru: 'Уход за детьми',
    },
    description: {
      uz: 'Chaqaloqlar uchun gipoallergen va yumshoq parvarish mahsulotlari',
      en: 'Hypoallergenic, gentle care essentials formulated for infants',
      ru: 'Гипоаллергенные и мягкие средства ухода для малышей',
    },
    image: IMAGES.baby,
  },
  {
    id: 'medical-devices',
    name: {
      uz: 'Tibbiy texnika',
      en: 'Medical Devices',
      ru: 'Медтехника',
    },
    description: {
      uz: 'Uyda nazorat qilish uchun aniq tonometr, termometr va ingalyatorlar',
      en: 'Accurate blood pressure monitors, thermometers, and nebulizers',
      ru: 'Точные тонометры, термометры и небулайзеры для дома',
    },
    image: IMAGES.devices,
  },
  {
    id: 'hygiene',
    name: {
      uz: 'Gigiyena vositalari',
      en: 'Hygiene Products',
      ru: 'Средства гигиены',
    },
    description: {
      uz: 'Antiseptiklar, og‘iz bo‘shlig‘i va kundalik himoya vositalari',
      en: 'Antiseptics, oral care, and everyday protective hygiene items',
      ru: 'Антисептики, уход за полостью рта и ежедневная гигиена',
    },
    image: IMAGES.baby,
  },
  {
    id: 'first-aid',
    name: {
      uz: 'Birinchi yordam',
      en: 'First Aid',
      ru: 'Первая помощь',
    },
    description: {
      uz: 'Steril bog‘lamlar, plastirlar va uy aptechkasi to‘plamlari',
      en: 'Sterile dressings, adhesive bandages, and emergency home kits',
      ru: 'Стерильные повязки, пластыри и готовые домашние аптечки',
    },
    image: IMAGES.firstAid,
  },
  {
    id: 'healthcare',
    name: {
      uz: 'Sog‘liqni saqlash',
      en: 'Healthcare Products',
      ru: 'Товары для здоровья',
    },
    description: {
      uz: 'Ortopedik tayanchlar, kompresslar va tiklanish mahsulotlari',
      en: 'Orthopedic supports, thermal compresses, and recovery products',
      ru: 'Ортопедическая поддержка, компрессы и средства восстановления',
    },
    image: IMAGES.firstAid,
  },
];
