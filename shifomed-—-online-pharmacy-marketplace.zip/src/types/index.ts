export type Language = 'uz' | 'en' | 'ru';

export interface LocalizedText {
  uz: string;
  en: string;
  ru: string;
}

export type CategoryId =
  | 'medicines'
  | 'vitamins'
  | 'personal-care'
  | 'baby-care'
  | 'medical-devices'
  | 'hygiene'
  | 'first-aid'
  | 'healthcare';

export interface Category {
  id: CategoryId;
  name: LocalizedText;
  description: LocalizedText;
  image: string;
}

export interface ProductSpecification {
  label: LocalizedText;
  value: LocalizedText;
}

export interface Product {
  id: string;
  sku: string;
  name: LocalizedText;
  description: LocalizedText;
  category: CategoryId;
  brand: string;
  priceUZS: number;
  previousPriceUZS?: number;
  image: string;
  inStock: boolean;
  stockCount: number;
  isPrescription: boolean;
  isBestseller?: boolean;
  isFeatured?: boolean;
  isNew?: boolean;
  popularity: number;
  dosageForm: LocalizedText;
  packSize: LocalizedText;
  manufacturer: LocalizedText;
  composition: LocalizedText;
  usage: LocalizedText;
  specifications: ProductSpecification[];
}

export interface CartItem {
  productId: string;
  quantity: number;
}

export type DeliveryMethodId = 'express' | 'standard' | 'pickup';

export interface DeliveryOption {
  id: DeliveryMethodId;
  priceUZS: number;
  freeThresholdUZS?: number;
}

export interface OrderRecord {
  orderNumber: string;
  createdAt: string;
  customerName: string;
  phone: string;
  address: string;
  notes?: string;
  deliveryMethod: DeliveryMethodId;
  deliveryCostUZS: number;
  subtotalUZS: number;
  discountUZS: number;
  totalUZS: number;
  hasPrescriptionItems: boolean;
  items: {
    productId: string;
    name: LocalizedText;
    brand: string;
    priceUZS: number;
    quantity: number;
    isPrescription: boolean;
  }[];
}

export interface ToastMessage {
  id: string;
  message: string;
  type: 'success' | 'info' | 'warning';
}
