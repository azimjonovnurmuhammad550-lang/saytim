import React from 'react';
import { Check, Info, AlertTriangle, X } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const ToastContainer: React.FC = () => {
  const { toasts, dismissToast } = useApp();

  if (toasts.length === 0) return null;

  return (
    <div
      aria-live="polite"
      className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm w-[calc(100vw-2rem)] sm:w-auto pointer-events-none"
    >
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className="pointer-events-auto flex items-center justify-between gap-3 bg-[#171717] text-white px-4 py-3 rounded shadow-lg border border-[#242424] text-sm"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            {toast.type === 'success' && <Check className="w-4 h-4 text-[#D71920] shrink-0" />}
            {toast.type === 'info' && <Info className="w-4 h-4 text-white shrink-0" />}
            {toast.type === 'warning' && <AlertTriangle className="w-4 h-4 text-[#D71920] shrink-0" />}
            <span className="truncate font-medium">{toast.message}</span>
          </div>
          <button
            type="button"
            onClick={() => dismissToast(toast.id)}
            aria-label="Close"
            className="text-[#777777] hover:text-white transition-colors p-1 shrink-0 focus-visible:outline-2 focus-visible:outline-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
};
