import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, ShoppingBag, CheckCircle2, AlertCircle, FileText } from 'lucide-react';
import { Product } from '../types';
import { useApp } from '../context/AppContext';
import { CATEGORIES } from '../data/categories';
import { formatUZS } from '../i18n/translations';
import { SafeImage } from './SafeImage';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { language, t, addToCart, isFavorite, toggleFavorite } = useApp();
  const favorited = isFavorite(product.id);
  const categoryObj = CATEGORIES.find((c) => c.id === product.category);

  const discountPercent =
    product.previousPriceUZS && product.previousPriceUZS > product.priceUZS
      ? Math.round(((product.previousPriceUZS - product.priceUZS) / product.previousPriceUZS) * 100)
      : null;

  return (
    <article className="group flex flex-col bg-white border border-[#E8E8E8] rounded transition-all duration-150 hover:border-[#171717]/40 hover:-translate-y-0.5">
      {/* Image Stage */}
      <div className="relative aspect-[4/3] bg-[#F7F7F7] overflow-hidden border-b border-[#E8E8E8]">
        <Link to={`/product/${product.id}`} className="block w-full h-full">
          <SafeImage
            src={product.image}
            alt={product.name[language]}
            fallbackLabel={product.name[language]}
            className="w-full h-full object-cover transition-transform duration-200 group-hover:scale-[1.02]"
          />
        </Link>

        {/* Top-left single crisp rectangular indicator (Discount OR Prescription, max 1 tag) */}
        {discountPercent ? (
          <span className="absolute top-3 left-3 bg-[#D71920] text-white text-xs font-semibold px-2 py-0.5 rounded-sm tabular-nums">
            -{discountPercent}%
          </span>
        ) : product.isPrescription ? (
          <span className="absolute top-3 left-3 bg-[#171717] text-white text-xs font-medium px-2 py-0.5 rounded-sm flex items-center gap-1">
            <FileText className="w-3 h-3" aria-hidden="true" />
            Rx
          </span>
        ) : null}

        {/* Favorite Toggle */}
        <button
          type="button"
          onClick={() => toggleFavorite(product.id)}
          aria-label={favorited ? t.product.removeFromFavorites : t.product.addToFavorites}
          aria-pressed={favorited}
          className={`absolute top-3 right-3 w-9 h-9 flex items-center justify-center rounded-sm border transition-colors focus-visible:outline-2 focus-visible:outline-[#D71920] ${
            favorited
              ? 'bg-[#D71920] border-[#D71920] text-white'
              : 'bg-white border-[#E8E8E8] text-[#171717] hover:border-[#171717]'
          }`}
        >
          <Heart className={`w-4 h-4 ${favorited ? 'fill-current' : ''}`} />
        </button>
      </div>

      {/* Content */}
      <div className="flex flex-col flex-1 p-4">
        {/* Clean unboxed metadata with typographic separator */}
        <div className="flex items-center gap-1.5 text-xs text-[#777777] mb-1.5 truncate">
          <span className="font-medium text-[#242424] truncate">{product.brand}</span>
          <span aria-hidden="true">·</span>
          <span className="truncate">{categoryObj ? categoryObj.name[language] : product.category}</span>
        </div>

        <Link
          to={`/product/${product.id}`}
          className="text-[15px] font-semibold text-[#171717] leading-snug line-clamp-2 min-h-[2.625rem] hover:text-[#D71920] transition-colors mb-2"
        >
          {product.name[language]}
        </Link>

        {/* Availability / Rx Status */}
        <div className="flex items-center gap-1.5 text-xs mb-3">
          {product.isPrescription ? (
            <span className="inline-flex items-center gap-1 text-[#242424] font-medium">
              <FileText className="w-3.5 h-3.5 text-[#D71920] shrink-0" aria-hidden="true" />
              {t.product.prescriptionRequired}
            </span>
          ) : product.inStock ? (
            <span className="inline-flex items-center gap-1 text-[#242424]">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#171717] shrink-0" aria-hidden="true" />
              {t.product.inStock}
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 text-[#777777]">
              <AlertCircle className="w-3.5 h-3.5 text-[#777777] shrink-0" aria-hidden="true" />
              {t.product.outOfStock}
            </span>
          )}
        </div>

        {/* Price & Action Footer */}
        <div className="mt-auto pt-3 border-t border-[#E8E8E8] flex items-end justify-between gap-2">
          <div className="min-w-0">
            {product.previousPriceUZS && (
              <div className="text-xs text-[#777777] line-through tabular-nums">
                {formatUZS(product.previousPriceUZS, language)}
              </div>
            )}
            <div className="text-base font-bold text-[#171717] tabular-nums whitespace-nowrap">
              {formatUZS(product.priceUZS, language)}
            </div>
          </div>

          {product.isPrescription ? (
            <Link
              to={`/product/${product.id}`}
              className="inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-sm border border-[#171717] text-[#171717] hover:bg-[#171717] hover:text-white transition-colors whitespace-nowrap shrink-0 min-h-[40px]"
            >
              {t.product.viewDetails}
            </Link>
          ) : (
            <button
              type="button"
              disabled={!product.inStock}
              onClick={() => addToCart(product.id, 1)}
              className={`inline-flex items-center justify-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-sm transition-colors whitespace-nowrap shrink-0 min-h-[40px] focus-visible:outline-2 focus-visible:outline-[#D71920] ${
                product.inStock
                  ? 'bg-[#D71920] text-white hover:bg-[#B5121B] cursor-pointer'
                  : 'bg-[#F7F7F7] text-[#777777] border border-[#E8E8E8] cursor-not-allowed'
              }`}
            >
              <ShoppingBag className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              <span>{t.product.addToCart}</span>
            </button>
          )}
        </div>
      </div>
    </article>
  );
};
