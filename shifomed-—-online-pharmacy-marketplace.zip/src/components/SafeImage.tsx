import React, { useState } from 'react';
import { Cross } from 'lucide-react';

interface SafeImageProps {
  src: string;
  alt: string;
  className?: string;
  fallbackLabel?: string;
}

export const SafeImage: React.FC<SafeImageProps> = ({ src, alt, className = '', fallbackLabel }) => {
  const [hasError, setHasError] = useState(false);

  if (hasError || !src) {
    return (
      <div
        role="img"
        aria-label={alt}
        className={`flex flex-col items-center justify-center bg-[#F7F7F7] border border-[#E8E8E8] text-[#777777] p-4 text-center ${className}`}
      >
        <div className="w-10 h-10 flex items-center justify-center border border-[#E8E8E8] bg-white text-[#D71920] mb-2">
          <Cross className="w-5 h-5" />
        </div>
        <span className="text-xs font-medium text-[#171717] line-clamp-2 max-w-[180px]">
          {fallbackLabel || alt}
        </span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={className}
      loading="lazy"
    />
  );
};
