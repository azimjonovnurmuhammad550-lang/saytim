import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';

export interface BreadcrumbItem {
  label: string;
  to?: string;
}

export const Breadcrumbs: React.FC<{ items: BreadcrumbItem[] }> = ({ items }) => {
  return (
    <nav aria-label="Breadcrumb" className="flex items-center flex-wrap gap-1.5 text-xs text-[#777777] mb-6">
      {items.map((item, idx) => {
        const isLast = idx === items.length - 1;
        return (
          <React.Fragment key={`${item.label}-${idx}`}>
            {idx > 0 && <ChevronRight className="w-3.5 h-3.5 text-[#777777] shrink-0" aria-hidden="true" />}
            {item.to && !isLast ? (
              <Link
                to={item.to}
                className="hover:text-[#171717] transition-colors whitespace-nowrap"
              >
                {item.label}
              </Link>
            ) : (
              <span className={isLast ? 'text-[#171717] font-medium truncate max-w-[260px]' : ''}>
                {item.label}
              </span>
            )}
          </React.Fragment>
        );
      })}
    </nav>
  );
};
