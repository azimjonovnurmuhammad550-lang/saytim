import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  Cross,
  Search,
  Heart,
  ShoppingBag,
  Menu,
  X,
  Globe,
  ChevronDown,
  ArrowRight,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CATEGORIES } from '../data/categories';
import { PRODUCTS } from '../data/products';
import { formatUZS } from '../i18n/translations';
import { Language } from '../types';
import { SafeImage } from './SafeImage';

const LANGUAGE_OPTIONS: { code: Language; label: string; short: string }[] = [
  { code: 'uz', label: 'O‘zbekcha', short: 'O‘ZB' },
  { code: 'en', label: 'English', short: 'ENG' },
  { code: 'ru', label: 'Русский', short: 'РУС' },
];

export const Header: React.FC = () => {
  const { language, setLanguage, t, cartCount, favorites } = useApp();
  const navigate = useNavigate();
  const location = useLocation();

  const [announcementVisible, setAnnouncementVisible] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchFocused, setSearchFocused] = useState(false);
  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);

  const searchContainerRef = useRef<HTMLDivElement>(null);
  const langContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setMobileMenuOpen(false);
    setMobileSearchOpen(false);
    setSearchFocused(false);
    setLangMenuOpen(false);
  }, [location.pathname, location.search]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(e.target as Node)) {
        setSearchFocused(false);
      }
      if (langContainerRef.current && !langContainerRef.current.contains(e.target as Node)) {
        setLangMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const searchSuggestions = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (q.length < 2) return [];
    return PRODUCTS.filter(
      (p) =>
        p.name[language].toLowerCase().includes(q) ||
        p.name.uz.toLowerCase().includes(q) ||
        p.name.en.toLowerCase().includes(q) ||
        p.name.ru.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q)
    ).slice(0, 5);
  }, [searchQuery, language]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const q = searchQuery.trim();
    setSearchFocused(false);
    setMobileSearchOpen(false);
    if (q) {
      navigate(`/catalog?q=${encodeURIComponent(q)}`);
    } else {
      navigate('/catalog');
    }
  };

  const currentLangOption =
    LANGUAGE_OPTIONS.find((opt) => opt.code === language) ?? LANGUAGE_OPTIONS[0];

  const navCategories = CATEGORIES.slice(0, 6);

  return (
    <>
      {/* Announcement Bar (non-sticky so mobile sticky height remains compact) */}
      {announcementVisible && (
        <div className="bg-[#171717] text-white text-xs border-b border-[#242424]">
          <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10 h-9 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 min-w-0 truncate">
              <span className="truncate">{t.announcement.text}</span>
              <Link
                to="/catalog"
                className="hidden sm:inline-flex items-center gap-1 text-white underline underline-offset-2 hover:text-[#D71920] transition-colors whitespace-nowrap shrink-0 font-medium"
              >
                {t.announcement.action}
                <ArrowRight className="w-3 h-3" aria-hidden="true" />
              </Link>
            </div>
            <button
              type="button"
              onClick={() => setAnnouncementVisible(false)}
              aria-label={t.nav.close}
              className="text-[#777777] hover:text-white transition-colors p-1 shrink-0"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Sticky Main Header */}
      <header className="sticky top-0 z-40 bg-white border-b border-[#E8E8E8]">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10 h-16 md:h-[72px] flex items-center justify-between gap-4 lg:gap-8">
          {/* Left: Brand Logo */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label={t.nav.menu}
              className="md:hidden w-10 h-10 -ml-2 flex items-center justify-center text-[#171717] hover:bg-[#F7F7F7] rounded-sm transition-colors"
            >
              <Menu className="w-5 h-5" />
            </button>
            <Link
              to="/"
              className="inline-flex items-center gap-2.5 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-[#D71920]"
            >
              <span className="w-8 h-8 bg-[#D71920] text-white flex items-center justify-center rounded-sm shrink-0">
                <Cross className="w-4 h-4 fill-current" aria-hidden="true" />
              </span>
              <span className="font-display text-lg sm:text-xl font-extrabold tracking-tight text-[#171717]">
                {t.brand.name}
              </span>
            </Link>
          </div>

          {/* Center: Desktop Search Bar with Live Suggestions */}
          <div ref={searchContainerRef} className="hidden md:block flex-1 max-w-xl relative">
            <form onSubmit={handleSearchSubmit} className="relative flex items-center">
              <Search
                className="w-4 h-4 text-[#777777] absolute left-3.5 pointer-events-none"
                aria-hidden="true"
              />
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setSearchFocused(true);
                }}
                onFocus={() => setSearchFocused(true)}
                placeholder={t.search.placeholder}
                aria-label={t.search.placeholder}
                className="w-full h-10 pl-10 pr-24 text-sm bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm text-[#171717] placeholder:text-[#777777] focus:bg-white focus:border-[#171717] focus:outline-none transition-colors"
              />
              <button
                type="submit"
                className="absolute right-1 top-1 bottom-1 px-3.5 bg-[#171717] hover:bg-[#D71920] text-white text-xs font-semibold rounded-sm transition-colors whitespace-nowrap cursor-pointer"
              >
                {t.search.submit}
              </button>
            </form>

            {/* Live Suggestions Dropdown */}
            {searchFocused && searchQuery.trim().length >= 2 && (
              <div className="absolute left-0 right-0 top-full mt-1.5 bg-white border border-[#E8E8E8] rounded-sm shadow-lg z-50 overflow-hidden">
                <div className="px-3.5 py-2 bg-[#F7F7F7] border-b border-[#E8E8E8] text-xs font-semibold text-[#777777]">
                  {t.search.suggestionsTitle}
                </div>
                {searchSuggestions.length === 0 ? (
                  <div className="px-4 py-5 text-sm text-[#777777] text-center">
                    {t.search.noResults}
                  </div>
                ) : (
                  <ul>
                    {searchSuggestions.map((product) => (
                      <li key={product.id} className="border-b border-[#E8E8E8] last:border-b-0">
                        <Link
                          to={`/product/${product.id}`}
                          onClick={() => setSearchFocused(false)}
                          className="flex items-center gap-3 px-3.5 py-2.5 hover:bg-[#F7F7F7] transition-colors"
                        >
                          <div className="w-11 h-9 bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm overflow-hidden shrink-0">
                            <SafeImage
                              src={product.image}
                              alt={product.name[language]}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="text-sm font-medium text-[#171717] truncate">
                              {product.name[language]}
                            </div>
                            <div className="text-xs text-[#777777] truncate">{product.brand}</div>
                          </div>
                          <div className="text-xs font-bold text-[#171717] tabular-nums whitespace-nowrap">
                            {formatUZS(product.priceUZS, language)}
                          </div>
                        </Link>
                      </li>
                    ))}
                    <li className="bg-[#F7F7F7] border-t border-[#E8E8E8]">
                      <button
                        type="button"
                        onClick={handleSearchSubmit}
                        className="w-full px-4 py-2.5 text-xs font-semibold text-[#D71920] hover:text-[#B5121B] flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <span>{t.search.viewAllResults}</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </li>
                  </ul>
                )}
              </div>
            )}
          </div>

          {/* Right Actions: Language, Favorites, Cart */}
          <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
            {/* Mobile Search Button */}
            <button
              type="button"
              onClick={() => setMobileSearchOpen((prev) => !prev)}
              aria-label={t.search.submit}
              className="md:hidden w-10 h-10 flex items-center justify-center text-[#171717] hover:bg-[#F7F7F7] rounded-sm transition-colors"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Language Selector */}
            <div ref={langContainerRef} className="relative">
              <button
                type="button"
                onClick={() => setLangMenuOpen((prev) => !prev)}
                aria-expanded={langMenuOpen}
                aria-haspopup="listbox"
                className="h-10 px-2.5 sm:px-3 inline-flex items-center gap-1.5 border border-[#E8E8E8] hover:border-[#171717] rounded-sm text-xs font-semibold text-[#171717] bg-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Globe className="w-4 h-4 text-[#777777]" aria-hidden="true" />
                <span className="hidden sm:inline">{currentLangOption.label}</span>
                <span className="sm:hidden">{currentLangOption.short}</span>
                <ChevronDown className="w-3.5 h-3.5 text-[#777777]" aria-hidden="true" />
              </button>

              {langMenuOpen && (
                <div
                  role="listbox"
                  aria-label="Language"
                  className="absolute right-0 top-full mt-1.5 w-40 bg-white border border-[#E8E8E8] rounded-sm shadow-lg py-1 z-50"
                >
                  {LANGUAGE_OPTIONS.map((opt) => (
                    <button
                      key={opt.code}
                      type="button"
                      role="option"
                      aria-selected={language === opt.code}
                      onClick={() => {
                        setLanguage(opt.code);
                        setLangMenuOpen(false);
                      }}
                      className={`w-full text-left px-3.5 py-2 text-sm flex items-center justify-between transition-colors cursor-pointer ${
                        language === opt.code
                          ? 'bg-[#F7F7F7] text-[#D71920] font-semibold'
                          : 'text-[#171717] hover:bg-[#F7F7F7]'
                      }`}
                    >
                      <span>{opt.label}</span>
                      <span className="text-[11px] text-[#777777] font-mono-num">{opt.short}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Favorites Icon */}
            <Link
              to="/favorites"
              aria-label={t.nav.favorites}
              className="relative w-10 h-10 inline-flex items-center justify-center border border-[#E8E8E8] hover:border-[#171717] rounded-sm text-[#171717] transition-colors shrink-0"
            >
              <Heart className="w-4 h-4" />
              {favorites.length > 0 && (
                <span className="absolute -top-1.5 -right-1.5 min-w-[18px] h-[18px] px-1 bg-[#171717] text-white text-[10px] font-bold rounded-sm flex items-center justify-center tabular-nums">
                  {favorites.length}
                </span>
              )}
            </Link>

            {/* Cart Icon */}
            <Link
              to="/cart"
              aria-label={t.nav.cart}
              className="relative h-10 px-3 inline-flex items-center gap-2 bg-[#171717] hover:bg-[#D71920] text-white rounded-sm text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
            >
              <ShoppingBag className="w-4 h-4 shrink-0" />
              <span className="hidden sm:inline">{t.nav.cart}</span>
              <span className="min-w-[20px] h-5 px-1 bg-white/15 text-white text-[11px] font-bold rounded-sm flex items-center justify-center tabular-nums">
                {cartCount}
              </span>
            </Link>
          </div>
        </div>

        {/* Mobile Expandable Search Bar */}
        {mobileSearchOpen && (
          <div className="md:hidden px-4 pb-3 border-t border-[#E8E8E8] bg-white pt-3">
            <form onSubmit={handleSearchSubmit} className="flex gap-2">
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t.search.mobilePlaceholder}
                autoFocus
                className="flex-1 h-10 px-3 text-sm bg-[#F7F7F7] border border-[#E8E8E8] rounded-sm text-[#171717] focus:outline-none focus:border-[#171717]"
              />
              <button
                type="submit"
                className="px-4 h-10 bg-[#D71920] text-white text-xs font-semibold rounded-sm whitespace-nowrap"
              >
                {t.search.submit}
              </button>
            </form>
          </div>
        )}
      </header>

      {/* Desktop Sub-Navigation Bar (non-sticky) */}
      <nav
        aria-label="Main navigation"
        className="hidden md:block bg-white border-b border-[#E8E8E8]"
      >
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10 h-11 flex items-center justify-between gap-6 overflow-x-auto">
          <div className="flex items-center gap-6">
            <Link
              to="/catalog"
              className={`text-xs font-semibold whitespace-nowrap shrink-0 transition-colors hover:text-[#D71920] ${
                location.pathname === '/catalog' && !location.search
                  ? 'text-[#D71920]'
                  : 'text-[#171717]'
              }`}
            >
              {t.nav.allProducts}
            </Link>
            {navCategories.map((cat) => {
              const isActive = location.search.includes(`category=${cat.id}`);
              return (
                <Link
                  key={cat.id}
                  to={`/catalog?category=${cat.id}`}
                  className={`text-xs font-medium whitespace-nowrap shrink-0 transition-colors hover:text-[#D71920] ${
                    isActive ? 'text-[#D71920] font-semibold' : 'text-[#242424]'
                  }`}
                >
                  {cat.name[language]}
                </Link>
              );
            })}
          </div>

          <div className="flex items-center gap-5 shrink-0 border-l border-[#E8E8E8] pl-5">
            <Link
              to="/catalog?discounted=true"
              className="text-xs font-semibold text-[#D71920] hover:text-[#B5121B] whitespace-nowrap shrink-0"
            >
              {t.nav.offers}
            </Link>
            <Link
              to="/delivery"
              className="text-xs font-medium text-[#777777] hover:text-[#171717] whitespace-nowrap shrink-0"
            >
              {t.nav.delivery}
            </Link>
            <Link
              to="/about"
              className="text-xs font-medium text-[#777777] hover:text-[#171717] whitespace-nowrap shrink-0"
            >
              {t.nav.about}
            </Link>
            <Link
              to="/contact"
              className="text-xs font-medium text-[#777777] hover:text-[#171717] whitespace-nowrap shrink-0"
            >
              {t.nav.contact}
            </Link>
          </div>
        </div>
      </nav>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 md:hidden flex">
          <div
            className="fixed inset-0 bg-black/50"
            onClick={() => setMobileMenuOpen(false)}
            aria-hidden="true"
          />
          <aside className="relative w-80 max-w-[85vw] bg-white h-full flex flex-col overflow-y-auto shadow-xl">
            <div className="px-4 h-16 border-b border-[#E8E8E8] flex items-center justify-between">
              <Link
                to="/"
                className="inline-flex items-center gap-2 font-display font-extrabold text-lg text-[#171717]"
              >
                <span className="w-7 h-7 bg-[#D71920] text-white flex items-center justify-center rounded-sm">
                  <Cross className="w-4 h-4 fill-current" />
                </span>
                {t.brand.name}
              </Link>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                aria-label={t.nav.close}
                className="w-10 h-10 flex items-center justify-center text-[#171717]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 border-b border-[#E8E8E8]">
              <div className="text-xs font-semibold text-[#777777] mb-2">Language</div>
              <div className="grid grid-cols-3 gap-1.5">
                {LANGUAGE_OPTIONS.map((opt) => (
                  <button
                    key={opt.code}
                    type="button"
                    onClick={() => setLanguage(opt.code)}
                    className={`py-2 px-2 text-xs font-semibold rounded-sm border transition-colors ${
                      language === opt.code
                        ? 'bg-[#D71920] text-white border-[#D71920]'
                        : 'bg-[#F7F7F7] text-[#171717] border-[#E8E8E8]'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="p-4 space-y-1 border-b border-[#E8E8E8]">
              <Link
                to="/"
                className="block py-2.5 px-2 text-sm font-semibold text-[#171717] hover:bg-[#F7F7F7] rounded-sm"
              >
                {t.nav.home}
              </Link>
              <Link
                to="/catalog"
                className="block py-2.5 px-2 text-sm font-semibold text-[#171717] hover:bg-[#F7F7F7] rounded-sm"
              >
                {t.nav.catalog}
              </Link>
              <Link
                to="/catalog?discounted=true"
                className="block py-2.5 px-2 text-sm font-semibold text-[#D71920] hover:bg-[#F7F7F7] rounded-sm"
              >
                {t.nav.offers}
              </Link>
              <Link
                to="/favorites"
                className="block py-2.5 px-2 text-sm font-medium text-[#171717] hover:bg-[#F7F7F7] rounded-sm"
              >
                {t.nav.favorites} ({favorites.length})
              </Link>
              <Link
                to="/cart"
                className="block py-2.5 px-2 text-sm font-medium text-[#171717] hover:bg-[#F7F7F7] rounded-sm"
              >
                {t.nav.cart} ({cartCount})
              </Link>
            </div>

            <div className="p-4 border-b border-[#E8E8E8]">
              <div className="text-xs font-semibold text-[#777777] mb-2">{t.nav.categories}</div>
              <div className="space-y-1">
                {CATEGORIES.map((cat) => (
                  <Link
                    key={cat.id}
                    to={`/catalog?category=${cat.id}`}
                    className="block py-2 px-2 text-sm text-[#242424] hover:bg-[#F7F7F7] rounded-sm"
                  >
                    {cat.name[language]}
                  </Link>
                ))}
              </div>
            </div>

            <div className="p-4 space-y-1 text-sm text-[#777777]">
              <Link to="/about" className="block py-2 px-2 hover:text-[#171717]">
                {t.nav.about}
              </Link>
              <Link to="/delivery" className="block py-2 px-2 hover:text-[#171717]">
                {t.nav.delivery}
              </Link>
              <Link to="/faq" className="block py-2 px-2 hover:text-[#171717]">
                {t.nav.faq}
              </Link>
              <Link to="/contact" className="block py-2 px-2 hover:text-[#171717]">
                {t.nav.contact}
              </Link>
            </div>
          </aside>
        </div>
      )}
    </>
  );
};
