import React from 'react';
import { Link } from 'react-router-dom';
import { Cross, Phone, Mail, MapPin, Clock } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CATEGORIES } from '../data/categories';

export const Footer: React.FC = () => {
  const { language, t } = useApp();

  return (
    <footer className="bg-[#171717] text-white border-t border-[#242424] mt-16">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12 border-b border-[#242424]">
          {/* Brand Column */}
          <div>
            <Link to="/" className="inline-flex items-center gap-2.5 mb-4">
              <span className="w-8 h-8 bg-[#D71920] text-white flex items-center justify-center rounded-sm">
                <Cross className="w-4 h-4 fill-current" aria-hidden="true" />
              </span>
              <span className="font-display text-xl font-extrabold tracking-tight text-white">
                {t.brand.name}
              </span>
            </Link>
            <p className="text-sm text-[#A3A3A3] leading-relaxed mb-4">
              {t.footer.aboutText}
            </p>
            <p className="text-xs text-[#777777] font-mono-num">{t.brand.license}</p>
          </div>

          {/* Categories Column */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-4">
              {t.footer.categoriesHeading}
            </h3>
            <ul className="space-y-2.5 text-sm text-[#A3A3A3]">
              {CATEGORIES.map((cat) => (
                <li key={cat.id}>
                  <Link
                    to={`/catalog?category=${cat.id}`}
                    className="hover:text-white transition-colors"
                  >
                    {cat.name[language]}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company & Info Column */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-4">
              {t.footer.companyHeading}
            </h3>
            <ul className="space-y-2.5 text-sm text-[#A3A3A3]">
              <li>
                <Link to="/about" className="hover:text-white transition-colors">
                  {t.footer.links.about}
                </Link>
              </li>
              <li>
                <Link to="/delivery" className="hover:text-white transition-colors">
                  {t.footer.links.delivery}
                </Link>
              </li>
              <li>
                <Link to="/faq" className="hover:text-white transition-colors">
                  {t.footer.links.faq}
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-white transition-colors">
                  {t.footer.links.contact}
                </Link>
              </li>
              <li>
                <Link to="/privacy" className="hover:text-white transition-colors">
                  {t.footer.links.privacy}
                </Link>
              </li>
              <li>
                <Link to="/terms" className="hover:text-white transition-colors">
                  {t.footer.links.terms}
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Column */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-4">
              {t.footer.contactHeading}
            </h3>
            <ul className="space-y-3 text-sm text-[#A3A3A3]">
              <li className="flex items-start gap-2.5">
                <Phone className="w-4 h-4 text-[#D71920] mt-0.5 shrink-0" aria-hidden="true" />
                <a href="tel:+998712004848" className="hover:text-white transition-colors font-mono-num">
                  +998 71 200 48 48
                </a>
              </li>
              <li className="flex items-start gap-2.5">
                <Mail className="w-4 h-4 text-[#D71920] mt-0.5 shrink-0" aria-hidden="true" />
                <a href="mailto:care@shifomed.uz" className="hover:text-white transition-colors">
                  care@shifomed.uz
                </a>
              </li>
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#D71920] mt-0.5 shrink-0" aria-hidden="true" />
                <span>{t.footer.address}</span>
              </li>
              <li className="flex items-start gap-2.5">
                <Clock className="w-4 h-4 text-[#D71920] mt-0.5 shrink-0" aria-hidden="true" />
                <span>{t.footer.hours}</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Disclaimer & Copyright */}
        <div className="pt-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 text-xs text-[#777777]">
          <p className="max-w-2xl leading-relaxed">{t.footer.disclaimer}</p>
          <p className="whitespace-nowrap shrink-0">{t.footer.copyright}</p>
        </div>
      </div>
    </footer>
  );
};
