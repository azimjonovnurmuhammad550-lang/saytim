import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { PRODUCTS } from '../data/products';
import { DELIVERY_FEES, TRANSLATIONS } from '../i18n/translations';
import { CartItem, DeliveryMethodId, Language, OrderRecord, Product, ToastMessage } from '../types';

const STORAGE_KEYS = {
  lang: 'shifomed_lang',
  cart: 'shifomed_cart',
  favorites: 'shifomed_favorites',
  orders: 'shifomed_orders',
} as const;

interface AppContextValue {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (typeof TRANSLATIONS)[Language];
  cart: CartItem[];
  cartCount: number;
  cartProducts: { product: Product; quantity: number }[];
  subtotalUZS: number;
  discountSavingsUZS: number;
  hasPrescriptionItemsInCart: boolean;
  deliveryMethod: DeliveryMethodId;
  setDeliveryMethod: (method: DeliveryMethodId) => void;
  deliveryCostUZS: number;
  totalUZS: number;
  addToCart: (productId: string, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  favorites: string[];
  isFavorite: (productId: string) => boolean;
  toggleFavorite: (productId: string) => void;
  clearFavorites: () => void;
  orders: OrderRecord[];
  saveOrder: (order: OrderRecord) => void;
  toasts: ToastMessage[];
  showToast: (message: string, type?: ToastMessage['type']) => void;
  dismissToast: (id: string) => void;
}

const AppContext = createContext<AppContextValue | undefined>(undefined);

function readStorage<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = readStorage<string>(STORAGE_KEYS.lang, 'uz');
    if (saved === 'uz' || saved === 'en' || saved === 'ru') return saved;
    return 'uz';
  });

  const [cart, setCart] = useState<CartItem[]>(() => readStorage<CartItem[]>(STORAGE_KEYS.cart, []));
  const [favorites, setFavorites] = useState<string[]>(() => readStorage<string[]>(STORAGE_KEYS.favorites, []));
  const [orders, setOrders] = useState<OrderRecord[]>(() => readStorage<OrderRecord[]>(STORAGE_KEYS.orders, []));
  const [deliveryMethod, setDeliveryMethod] = useState<DeliveryMethodId>('standard');
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEYS.lang, JSON.stringify(language));
      document.documentElement.lang = language;
    } catch {
      // Ignore storage errors in restricted environments
    }
  }, [language]);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEYS.cart, JSON.stringify(cart));
    } catch {
      // Ignore storage errors
    }
  }, [cart]);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEYS.favorites, JSON.stringify(favorites));
    } catch {
      // Ignore storage errors
    }
  }, [favorites]);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEYS.orders, JSON.stringify(orders));
    } catch {
      // Ignore storage errors
    }
  }, [orders]);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((item) => item.id !== id));
  }, []);

  const showToast = useCallback((message: string, type: ToastMessage['type'] = 'success') => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    setToasts((prev) => [...prev.slice(-2), { id, message, type }]);
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((item) => item.id !== id));
    }, 3200);
  }, []);

  const setLanguage = useCallback(
    (lang: Language) => {
      setLanguageState(lang);
      showToast(TRANSLATIONS[lang].toasts.languageChanged, 'info');
    },
    [showToast]
  );

  const t = TRANSLATIONS[language];

  const addToCart = useCallback(
    (productId: string, quantity = 1) => {
      const product = PRODUCTS.find((p) => p.id === productId);
      if (!product || !product.inStock) return;
      setCart((prev) => {
        const existing = prev.find((item) => item.productId === productId);
        if (existing) {
          return prev.map((item) =>
            item.productId === productId
              ? { ...item, quantity: Math.min(item.quantity + quantity, product.stockCount) }
              : item
          );
        }
        return [...prev, { productId, quantity: Math.min(quantity, product.stockCount) }];
      });
      showToast(`${product.name[language]} — ${TRANSLATIONS[language].toasts.addedToCart}`, 'success');
    },
    [language, showToast]
  );

  const removeFromCart = useCallback(
    (productId: string) => {
      setCart((prev) => prev.filter((item) => item.productId !== productId));
      showToast(TRANSLATIONS[language].toasts.removedFromCart, 'info');
    },
    [language, showToast]
  );

  const updateCartQuantity = useCallback((productId: string, quantity: number) => {
    const product = PRODUCTS.find((p) => p.id === productId);
    if (!product) return;
    if (quantity <= 0) {
      setCart((prev) => prev.filter((item) => item.productId !== productId));
      return;
    }
    const clamped = Math.min(quantity, product.stockCount);
    setCart((prev) =>
      prev.map((item) => (item.productId === productId ? { ...item, quantity: clamped } : item))
    );
  }, []);

  const clearCart = useCallback(() => {
    setCart([]);
  }, []);

  const isFavorite = useCallback((productId: string) => favorites.includes(productId), [favorites]);

  const toggleFavorite = useCallback(
    (productId: string) => {
      const product = PRODUCTS.find((p) => p.id === productId);
      if (!product) return;
      setFavorites((prev) => {
        const exists = prev.includes(productId);
        const next = exists ? prev.filter((id) => id !== productId) : [...prev, productId];
        showToast(
          `${product.name[language]} — ${
            exists ? TRANSLATIONS[language].toasts.removedFromFavorites : TRANSLATIONS[language].toasts.addedToFavorites
          }`,
          exists ? 'info' : 'success'
        );
        return next;
      });
    },
    [language, showToast]
  );

  const clearFavorites = useCallback(() => {
    setFavorites([]);
  }, []);

  const saveOrder = useCallback((order: OrderRecord) => {
    setOrders((prev) => [order, ...prev]);
  }, []);

  const cartProducts = useMemo(() => {
    return cart
      .map((item) => {
        const product = PRODUCTS.find((p) => p.id === item.productId);
        return product ? { product, quantity: item.quantity } : null;
      })
      .filter((entry): entry is { product: Product; quantity: number } => entry !== null);
  }, [cart]);

  const cartCount = useMemo(() => cart.reduce((acc, item) => acc + item.quantity, 0), [cart]);

  const subtotalUZS = useMemo(
    () => cartProducts.reduce((sum, item) => sum + item.product.priceUZS * item.quantity, 0),
    [cartProducts]
  );

  const discountSavingsUZS = useMemo(
    () =>
      cartProducts.reduce((sum, item) => {
        const prev = item.product.previousPriceUZS;
        if (prev && prev > item.product.priceUZS) {
          return sum + (prev - item.product.priceUZS) * item.quantity;
        }
        return sum;
      }, 0),
    [cartProducts]
  );

  const hasPrescriptionItemsInCart = useMemo(
    () => cartProducts.some((item) => item.product.isPrescription),
    [cartProducts]
  );

  const deliveryCostUZS = useMemo(() => {
    if (cartProducts.length === 0) return 0;
    if (deliveryMethod === 'pickup') return DELIVERY_FEES.pickup;
    if (deliveryMethod === 'express') return DELIVERY_FEES.express;
    return subtotalUZS >= DELIVERY_FEES.freeStandardThreshold ? 0 : DELIVERY_FEES.standard;
  }, [cartProducts.length, deliveryMethod, subtotalUZS]);

  const totalUZS = subtotalUZS + deliveryCostUZS;

  const value: AppContextValue = {
    language,
    setLanguage,
    t,
    cart,
    cartCount,
    cartProducts,
    subtotalUZS,
    discountSavingsUZS,
    hasPrescriptionItemsInCart,
    deliveryMethod,
    setDeliveryMethod,
    deliveryCostUZS,
    totalUZS,
    addToCart,
    removeFromCart,
    updateCartQuantity,
    clearCart,
    favorites,
    isFavorite,
    toggleFavorite,
    clearFavorites,
    orders,
    saveOrder,
    toasts,
    showToast,
    dismissToast,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) {
    throw new Error('useApp must be used inside AppProvider');
  }
  return ctx;
}
